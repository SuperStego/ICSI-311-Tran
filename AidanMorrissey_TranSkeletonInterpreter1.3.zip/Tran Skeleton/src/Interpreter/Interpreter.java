package Interpreter;

import AST.*;

import java.util.*;

public class Interpreter {
    private TranNode top;

    /** Constructor - get the interpreter ready to run. Set members from parameters and "prepare" the class.
     *
     * Store the tran node.
     * Add any built-in methods to the AST
     * @param top - the head of the AST
     */
    public Interpreter(TranNode top) {
        this.top = top;

        // Add console as a class with a method "write"
        ClassNode console = new ClassNode();
        console.name = "console";

        // Create the "write" method
        ConsoleWrite consoleWrite = new ConsoleWrite();
        consoleWrite.name = "write";
        consoleWrite.isVariadic = true;
        consoleWrite.isPrivate = false;
        consoleWrite.isShared = true;
        console.methods.add(consoleWrite);

        // Add "console" to the classes in the TranNode
        this.top.Classes.add(console);

        createIterator();

        // Create the Times class and the .times() method
        addTimesClass();

        System.out.println(this.top.Classes.get(2));

        // Create the Built-in .clone() method
        addCloneMethod();
    }

    /**
     * Creates an iterator interface which has a getNext() method and adds it to the list of interfaces
     */
    private void createIterator() {
        // Create Interface iterator
        InterfaceNode iterator = new InterfaceNode();
        iterator.name = "iterator";

        // Create method getNext()
        MethodHeaderNode getNext = new MethodHeaderNode();
        getNext.name = "getNext";

        // Create boolean first (if the getNext() is done)
        VariableDeclarationNode bool = new VariableDeclarationNode();
        bool.name = "bool";
        bool.type = "boolean";

        // Create next (will always return a number for this version of the language)
        VariableDeclarationNode next = new VariableDeclarationNode();
        next.name = "next";
        next.type = "number";

        // Add the returns to getNext
        getNext.returns.add(bool);
        getNext.returns.add(next);

        // Add to the iterator interface
        iterator.methods.add(getNext);

    }

    /**
     * Creates a class Times which implements the iterator interface
     * Makes it possible to use the .times() method
     */
    private void addTimesClass() {
        // Make a class for the .times() method
        ClassNode timesClass = new ClassNode();
        timesClass.name = "Times";

        // Implement iterator (for .times())
        timesClass.interfaces.add("iterator");

        // Create a member to store what iteration we're on
        MemberNode iteration = new MemberNode();
        VariableDeclarationNode iterationVDN = new VariableDeclarationNode();
        iterationVDN.name = "iteration";
        iterationVDN.type = "number";
        iteration.declaration = iterationVDN;
        timesClass.members.add(iteration);

        // Create a member to store what iteration to stop
        MemberNode numberToStop = new MemberNode();
        VariableDeclarationNode numberToStopVDN = new VariableDeclarationNode();
        numberToStopVDN.name = "numberToStop";
        numberToStopVDN.type = "number";
        numberToStop.declaration = numberToStopVDN;
        timesClass.members.add(numberToStop);

        // Create a method for getNext
        MethodDeclarationNode getNextMD = new MethodDeclarationNode();
        getNextMD.name = "getNext";
        VariableDeclarationNode bool = new VariableDeclarationNode();
        bool.name = "bool";
        bool.type = "boolean";
        getNextMD.returns.add(bool);
        VariableDeclarationNode next = new VariableDeclarationNode();
        next.name = "next";
        next.type = "number";
        getNextMD.returns.add(next);

        // Create statementNodes for what's within the getNext() method

        // Next = iteration
        AssignmentNode assignNext = new AssignmentNode();
        VariableReferenceNode nextVRN = new VariableReferenceNode();
        nextVRN.name = "next";
        assignNext.target = nextVRN;
        VariableReferenceNode iterationVRN = new VariableReferenceNode();
        iterationVRN.name = "iteration";
        assignNext.expression = iterationVRN;
        getNextMD.statements.add(assignNext);

        // if(next >= numberToStop)
        //     bool = false
        // else
        //     bool = true
        IfNode ifNode = new IfNode();

        // Condition = next >= numberToStop
        CompareNode compareNode = new CompareNode();
        compareNode.left = nextVRN;
        compareNode.op = CompareNode.CompareOperations.ge;
        VariableReferenceNode numberToStopVRN = new VariableReferenceNode();
        numberToStopVRN.name = "numberToStop";
        compareNode.right = numberToStopVRN;
        ifNode.condition = compareNode;

        // bool = false
        AssignmentNode assignBoolFalse = new AssignmentNode();
        VariableReferenceNode boolVRN = new VariableReferenceNode();
        boolVRN.name = "bool";
        assignBoolFalse.target = boolVRN;
        assignBoolFalse.expression = new BooleanLiteralNode(false);
        ifNode.statements = new LinkedList<>();
        ifNode.statements.add(assignBoolFalse);

        // else
        ElseNode elseNode = new ElseNode();

        // bool = true
        AssignmentNode assignBoolTrue = new AssignmentNode();
        assignBoolTrue.target = boolVRN;
        assignBoolTrue.expression = new BooleanLiteralNode(true);
        elseNode.statements = new LinkedList<>();
        elseNode.statements.add(assignBoolTrue);
        ifNode.elseStatement = Optional.of(elseNode);

        // Add ifNode to getNextMD
        getNextMD.statements.add(ifNode);

        // iteration = iteration + 1.0
        AssignmentNode assignIteration = new AssignmentNode();
        assignIteration.target = iterationVRN;
        MathOpNode add1ToIteration = new MathOpNode();
        add1ToIteration.left = iterationVRN;
        add1ToIteration.op = MathOpNode.MathOperations.add;
        NumericLiteralNode one = new NumericLiteralNode();
        one.value = 1;
        add1ToIteration.right = one;
        assignIteration.expression = add1ToIteration;
        getNextMD.statements.add(assignIteration);

        // Add getNextMD to timesClass
        timesClass.methods.add(getNextMD);

        // Make a constructor to set the numberToStop
        ConstructorNode timesConstructor = new ConstructorNode();

        // construct(number maxIteration)
        //     numberToStop = maxIteration
        VariableDeclarationNode maxIteration = new VariableDeclarationNode();
        maxIteration.name = "maxIteration";
        maxIteration.type = "number";
        timesConstructor.parameters.add(maxIteration);

        // numberToStop = maxIteration
        AssignmentNode assignMaxIteration = new AssignmentNode();
        assignMaxIteration.target = numberToStopVRN;
        VariableReferenceNode maxIterationVRN = new VariableReferenceNode();
        maxIterationVRN.name = "maxIteration";
        assignMaxIteration.expression = maxIterationVRN;

        // Add statement to timesConstructor and add the constructor to timesClass
        timesConstructor.statements.add(assignMaxIteration);
        timesClass.constructors.add(timesConstructor);

        this.top.Classes.add(timesClass);
    }

    /**
     * Adds the built-in .clone() method which creates a copy of a variable
     */
    private void addCloneMethod() {
        BuiltInMethodDeclarationNode clone = new BuiltInMethodDeclarationNode() {
            @Override
            public List<InterpreterDataType> Execute(List<InterpreterDataType> params) {
                if(params.size() != 1)
                    throw new RuntimeException(".clone() must have no parameters");
                // BooleanIDT
                if(params.getFirst() instanceof BooleanIDT booleanIDT)
                    return List.of(new BooleanIDT(booleanIDT.Value));
                // CharIDT
                else if(params.getFirst() instanceof CharIDT charIDT)
                    return List.of(new CharIDT(charIDT.Value));
                // NumberIDT
                else if(params.getFirst() instanceof NumberIDT numberIDT)
                    return List.of(new NumberIDT(numberIDT.Value));
                // ObjectIDT
                else if(params.getFirst() instanceof ObjectIDT objectIDT) {
                    ObjectIDT newObjectIDT = new ObjectIDT(objectIDT.astNode);
                    for(String key: objectIDT.members.keySet())
                        newObjectIDT.members.put(key, objectIDT.members.get(key));
                    return List.of(newObjectIDT);
                }
                // ReferenceIDT
                else if(params.getFirst() instanceof ReferenceIDT referenceIDT) {
                    ReferenceIDT newReferenceIDT = new ReferenceIDT();
                    newReferenceIDT.Assign(referenceIDT);
                    return List.of(newReferenceIDT);
                }
                // StringIDT
                else if(params.getFirst() instanceof StringIDT stringIDT)
                    return List.of(new StringIDT(stringIDT.Value));
                return List.of();
            }
        };
        clone.name = "clone";

        this.top.Classes.getFirst().methods.add(clone);
    }

    /**
     * This is the public interface to the interpreter. After parsing, we will create an interpreter and call start to
     * start interpreting the code.
     *
     * Search the classes in Tran for a method that is "isShared", named "start", that is not private and has no parameters
     * Call "InterpretMethodCall" on that method, then return.
     * Throw an exception if no such method exists.
     */
    public void start() {
        // Search through all the classes
        for(ClassNode classNode: top.Classes)
        {
            // Create an ObjectIDT node
            ObjectIDT newObjectIDT = new ObjectIDT(classNode);
            // Add members to the ObjectIDT members hashmap
            for(MemberNode memberNode: classNode.members)
            {
                InterpreterDataType dataType = instantiate(memberNode.declaration.type);
                newObjectIDT.members.put(memberNode.declaration.name, dataType);
            }
            // Go through the methods, look for start() and interpret it
            for(MethodDeclarationNode methodDeclarationNode: classNode.methods)
            {
                if(methodDeclarationNode.name.equals("start"))
                {
                    if(!methodDeclarationNode.isShared || methodDeclarationNode.isPrivate || !methodDeclarationNode.parameters.isEmpty())
                        throw new RuntimeException("start() method not properly defined (not shared, is private or contains parameters) "+methodDeclarationNode);
                    interpretMethodCall(Optional.of(newObjectIDT), methodDeclarationNode, new ArrayList<InterpreterDataType>());
                    return;
                }
            }
        }
        throw new RuntimeException("Missing start() method");
    }

    //              Running Methods

    /**
     * Find the method (local to this class, shared (like Java's system.out.print), or a method on another class)
     * Evaluate the parameters to have a list of values
     * Use interpretMethodCall() to actually run the method.
     *
     * Call GetParameters() to get the parameter value list
     * Find the method. This is tricky - there are several cases:
     * someLocalMethod() - has NO object name. Look in "object"
     * console.write() - the objectName is a CLASS and the method is shared
     * bestStudent.getGPA() - the objectName is a local or a member
     *
     * Once you find the method, call InterpretMethodCall() on it. Return the list that it returns.
     * Throw an exception if we can't find a match.
     * @param object - the object we are inside right now (might be empty)
     * @param locals - the current local variables
     * @param mc - the method call
     * @return - the return values
     */
    private List<InterpreterDataType> findMethodForMethodCallAndRunIt(Optional<ObjectIDT> object, HashMap<String, InterpreterDataType> locals, MethodCallStatementNode mc) {
        List<InterpreterDataType> params = getParameters(object, locals, mc);

        // No object name provided means it must be this object
        if(mc.objectName.isEmpty())
        {
            if(object.isEmpty())
                throw new RuntimeException("Missing reference to object or method not present in this class for "+mc);
            // Find the method in the object
            for(MethodDeclarationNode methodDeclarationNode: object.get().astNode.methods)
            {
                if(methodDeclarationNode.name.equals(mc.methodName)) {
//                    if(methodDeclarationNode.name.equals("clone"))
//                        params.add(methodDeclarationNode.parameters.getFirst());
                    return interpretMethodCall(object, methodDeclarationNode, params);
                }
            }
            // If we didn't find the method throw an error
            throw new RuntimeException("Method "+mc+"not found in "+object.get().astNode.name);
        }
        // If there is an objectName
        else
        {
            // Look through the available classes for the class described
            for(ClassNode classNode: top.Classes) {
                // See if the class matches the objectName
                if (classNode.name.equals(mc.objectName.get())) {
                    ObjectIDT newObjectIDT = new ObjectIDT(classNode);
                    // Go through all the methods in the class until the correct one is found
                    for (MethodDeclarationNode methodDeclarationNode : classNode.methods) {
                        if (methodDeclarationNode.isShared && methodDeclarationNode.name.equals(mc.methodName))
                            return interpretMethodCall(Optional.of(newObjectIDT), methodDeclarationNode, params);
                    }
                    // If we've gone through and didn't find the method, it's either not shared or doesn't exist
                    throw new RuntimeException("Shared method " + mc + "not found in " + classNode.name);
                }
            }

            // Now look through locals for a matching name
            if(locals.containsKey(mc.objectName.get()))
            {
                // if method is .clone()
                if(mc.methodName.equals("clone")){
                    VariableReferenceNode variableToBeCloned = new VariableReferenceNode();
                    variableToBeCloned.name = mc.objectName.get();
                    mc.parameters.add(variableToBeCloned);
                    mc.objectName = Optional.empty();
                    return findMethodForMethodCallAndRunIt(object, locals, mc);
                }

                InterpreterDataType idt = locals.get(mc.objectName.get());
                if(idt instanceof ReferenceIDT referenceIDT) {
                    if(referenceIDT.refersTo.isPresent()) {
                        mc.objectName = Optional.empty();
                        MethodDeclarationNode methodDeclarationNode = getMethodFromObject(referenceIDT.refersTo.get(), mc, params);

                        return interpretMethodCall(referenceIDT.refersTo, methodDeclarationNode, params);
                    }
                    else throw new RuntimeException("Missing reference to, object or method not present in this class for "+mc);
                }
            }
            throw new RuntimeException("Method is never initialized "+mc);
        }
    }

    /**
     * Run a "prepared" method (found, parameters evaluated)
     * This is split from findMethodForMethodCallAndRunIt() because there are a few cases where we don't need to do the finding:
     * in start() and dealing with loops with iterator objects, for example.
     *
     * Check to see if "m" is a built-in. If so, call Execute() on it and return
     * Make local variables, per "m"
     * If the number of passed in values doesn't match m's "expectations", throw
     * Add the parameters by name to locals.
     * Call InterpretStatementBlock
     * Build the return list - find the names from "m", then get the values for those names and add them to the list.
     * @param object - The object this method is being called on (might be empty for shared)
     * @param m - Which method is being called
     * @param values - The values to be passed in
     * @return the returned values from the method
     */
    private List<InterpreterDataType> interpretMethodCall(Optional<ObjectIDT> object, MethodDeclarationNode m, List<InterpreterDataType> values) {
        var retVal = new LinkedList<InterpreterDataType>();
        // If m is a built-in method call Execute() on it and return
        if(m instanceof BuiltInMethodDeclarationNode)
            return ((BuiltInMethodDeclarationNode)m).Execute(values);

        HashMap<String, InterpreterDataType> locals = new HashMap<String, InterpreterDataType>();
        // Make local variables
        for(VariableDeclarationNode vdn: m.locals)
            locals.put(vdn.name, instantiate(vdn.type));

        // add local variables from return values
        for(VariableDeclarationNode vdn: m.returns)
            locals.put(vdn.name, instantiate(vdn.type));

        // If the number of passed in values doesn't match m's "expectations", throw
        if(values.size() != m.parameters.size())
            throw new RuntimeException("Number of parameters mismatch for "+m);

        // Add the parameters by name to locals.
        for(int i = 0; i < m.parameters.size(); i++)
            locals.put(m.parameters.get(i).name, values.get(i));

        // Call InterpretStatementBlock
        interpretStatementBlock(object,m.statements,locals);

        // Build the return list - find the names from "m", then get the values for those names and add them to the list.
        for(VariableDeclarationNode vdn: m.returns)
            retVal.add(findVariable(vdn.name, locals, object));

        return retVal;
    }

    //              Running Constructors

    /**
     * This is a special case of the code for methods. Just different enough to make it worthwhile to split it out.
     *
     * Call GetParameters() to populate a list of IDT's
     * Call GetClassByName() to find the class for the constructor
     * If we didn't find the class, throw an exception
     * Find a constructor that is a good match - use DoesConstructorMatch()
     * Call InterpretConstructorCall() on the good match
     * @param callerObj - the object that we are inside when we called the constructor
     * @param locals - the current local variables (used to fill parameters)
     * @param mc  - the method call for this construction
     * @param newOne - the object that we just created that we are calling the constructor for
     */
    private void findConstructorAndRunIt(Optional<ObjectIDT> callerObj, HashMap<String, InterpreterDataType> locals, MethodCallStatementNode mc, ObjectIDT newOne) {
        // Call GetParameters() to populate a list of IDT's
        List<InterpreterDataType> params = getParameters(callerObj, locals, mc);

        // Call GetClassByName() to find the class for the constructor
        Optional<ClassNode> optionalClassNode = getClassByName(newOne.astNode.name);

        // If we didn't find the class, throw an exception
        if(optionalClassNode.isEmpty())
            throw new RuntimeException("Class "+newOne.astNode.name+" not found");

        // Find a constructor that is a good match - use DoesConstructorMatch()
        for(ConstructorNode construct: optionalClassNode.get().constructors)
        {
            // Call InterpretConstructorCall() on the good match
            if(doesConstructorMatch(construct, mc, params))
            {
                interpretConstructorCall(newOne, construct, params);
                break;
            }

        }
    }

    /**
     * Similar to interpretMethodCall, but "just different enough" - for example, constructors don't return anything.
     *
     * Creates local variables (as defined by the ConstructorNode), calls Instantiate() to do the creation
     * Checks to ensure that the right number of parameters were passed in, if not throw.
     * Adds the parameters (with the names from the ConstructorNode) to the locals.
     * Calls InterpretStatementBlock
     * @param object - the object that we allocated
     * @param c - which constructor is being called
     * @param values - the parameter values being passed to the constructor
     */
    private void interpretConstructorCall(ObjectIDT object, ConstructorNode c, List<InterpreterDataType> values) {
        // Creates local variables (as defined by the ConstructorNode), calls Instantiate() to do the creation
        HashMap<String, InterpreterDataType> locals = new HashMap<String, InterpreterDataType>();
        for(VariableDeclarationNode vdn: c.locals)
            locals.put(vdn.name, instantiate(vdn.type));

        // Checks to ensure that the right number of parameters were passed in, if not throw.
        if(values.size() != c.parameters.size())
            throw new RuntimeException("Number of parameters mismatch for "+c);

        // Adds the parameters (with the names from the ConstructorNode) to the locals.
        for(int i = 0; i < c.parameters.size(); i++)
            locals.put(c.parameters.get(i).name, values.get(i));

        // Calls InterpretStatementBlock
        interpretStatementBlock(Optional.of(object), c.statements, locals);
    }

    //              Running Instructions

    /**
     * Given a block (which could be from a method or an "if" or "loop" block, run each statement.
     * Blocks, by definition, do ever statement, so iterating over the statements makes sense.
     *
     * For each statement in statements:
     * check the type:
     *      For AssignmentNode, FindVariable() to get the target. Evaluate() the expression. Call Assign() on the target with the result of Evaluate()
     *      For MethodCallStatementNode, call doMethodCall(). Loop over the returned values and copy the into our local variables
     *      For LoopNode - there are 2 kinds.
     *          Setup:
     *          If this is a Loop over an iterator (an Object node whose class has "iterator" as an interface)
     *              Find the "getNext()" method; throw an exception if there isn't one
     *          Loop:
     *          While we are not done:
     *              if this is a boolean loop, Evaluate() to get true or false.
     *              if this is an iterator, call "getNext()" - it has 2 return values. The first is a boolean (was there another?), the second is a value
     *              If the loop has an assignment variable, populate it: for boolean loops, the true/false. For iterators, the "second value"
     *              If our answer from above is "true", InterpretStatementBlock() on the body of the loop.
     *       For If - Evaluate() the condition. If true, InterpretStatementBlock() on the if's statements. If not AND there is an else, InterpretStatementBlock on the else body.
     * @param object - the object that this statement block belongs to (used to get member variables and any members without an object)
     * @param statements - the statements to run
     * @param locals - the local variables
     */
    private void interpretStatementBlock(Optional<ObjectIDT> object, List<StatementNode> statements, HashMap<String, InterpreterDataType> locals) {
        // Iterate through the list of statements
        for(StatementNode statement: statements)
        {
            // AssignmentNode
            if(statement instanceof AssignmentNode)
            {
                // FindVariable() to get the target
                InterpreterDataType target = findVariable(((AssignmentNode)statement).target.name, locals, object);
                // Evaluate the expression
                InterpreterDataType result = evaluate(locals, object, ((AssignmentNode)statement).expression);
                // Call Assign() on the target with the result of Evaluate()
                target.Assign(result);
            }
            // MethodCallStatementNode
            else if(statement instanceof MethodCallStatementNode)
            {
                // call doMethodCall
                var retVal = findMethodForMethodCallAndRunIt(object, locals, (MethodCallStatementNode)statement);
                // Loop over the returned values and copy the into our local variables
                for(int i = 0; i < ((MethodCallStatementNode) statement).returnValues.size(); i++)
                    locals.put(((MethodCallStatementNode) statement).returnValues.get(i).name, retVal.get(i));
            }
            // LoopNode
            else if(statement instanceof LoopNode)
            {
                // If this is a Loop over an iterator (an Object node whose class has "iterator" as an interface)
                if(((LoopNode)statement).expression instanceof VariableReferenceNode)
                {
                    InterpreterDataType variable = findVariable(((VariableReferenceNode)((LoopNode)statement).expression).name, locals, object);
                    if(variable instanceof ReferenceIDT)
                    {
                        // If there is no ObjectIDT throw an exception
                        Optional<ObjectIDT> optionalObjectIDT = (((ReferenceIDT)variable).refersTo);
                        if(optionalObjectIDT.isEmpty())
                            throw new RuntimeException("Loop reference "+((ReferenceIDT)variable).refersTo+" doesn't refer to any class");
                        ObjectIDT objectIDT = optionalObjectIDT.get();

                        // Find if there is an interface with the name "iterator" through an exception if its not found
                        boolean foundIteratorInterface = false;
                        for(String interfaceName: objectIDT.astNode.interfaces)
                        {
                            if (interfaceName.equals("iterator")) {
                                foundIteratorInterface = true;
                                break;
                            }
                        }
                        if(!foundIteratorInterface)
                            throw new RuntimeException("Class "+objectIDT.astNode.name+" does not implement iterator");

                        // Find the "getNext()" method; throw an exception if there isn't one
                        MethodCallStatementNode methodCallStatementNode = new MethodCallStatementNode();
                        methodCallStatementNode.methodName = "getNext";

                        // it has 2 return values. The first is a boolean (was there another?), the second is a value
                        VariableReferenceNode bool = new VariableReferenceNode();
                        bool.name = "done";
                        VariableReferenceNode value = new VariableReferenceNode();
                        value.name = "value";
                        methodCallStatementNode.returnValues.add(bool);
                        methodCallStatementNode.returnValues.add(value);

                        // This will throw an exception if the method is not found
                        MethodDeclarationNode getNext = getMethodFromObject(objectIDT, methodCallStatementNode, new ArrayList<>());

                        // if this is an iterator, call "getNext()"
                        var retVals = interpretMethodCall(Optional.of(objectIDT), getNext, new LinkedList<>());

                        // while we're not done
                        while(((BooleanIDT)retVals.getFirst()).Value)
                        {
                            // If the loop has an assignment variable, populate it. For iterators, the "second value"
                            Optional<VariableReferenceNode> optionalVRN = ((LoopNode)statement).assignment;
                            if(optionalVRN.isPresent()) {
                                // Find the key with the same name and replace it with the new value
                                if (locals.containsKey(optionalVRN.get().name))
                                    locals.replace(optionalVRN.get().name, retVals.get(1));
                                else if (object.isPresent() && object.get().members.containsKey(optionalVRN.get().name))
                                    object.get().members.replace(optionalVRN.get().name, retVals.get(1));
                                    // if it doesn't exist throw exception
                                else throw new RuntimeException("Assignment not located in " + object);
                            }
                            // If our answer from above is "true", InterpretStatementBlock() on the body of the loop.
                            interpretStatementBlock(object, ((LoopNode)statement).statements, locals);

                            // call "getNext()"
                            retVals = interpretMethodCall(Optional.of(objectIDT), getNext, new LinkedList<>());
                        }
                    }
                    else if(variable instanceof BooleanIDT){
                        // Call a method to interpret the loop
                        interpretBooleanLoop(object, locals, (LoopNode) statement);
                    }
                    else throw new RuntimeException("Variable "+variable+" cannot be evaulated as boolean");
                }
                // method times()
                else if(((LoopNode)statement).expression instanceof MethodCallExpressionNode mc)
                {
                    if(mc.methodName.equals("times"))
                    {
                        // Make sure the objectName is a number variable in scope
                        if(mc.objectName.isEmpty())
                            throw new RuntimeException("Method times() must utilize a number variable");
                        InterpreterDataType idt = findVariable(mc.objectName.get(), locals, object);
                        if(!(idt instanceof NumberIDT))
                            throw new RuntimeException("Method times() requires a number variable");

                        // Get the Times class
                        Optional<ClassNode> optionalClassNode = getClassByName("Times");
                        if(optionalClassNode.isEmpty())
                            throw new RuntimeException("Class Times not found");

                        // Make the times() object
                        ObjectIDT timesObject = new ObjectIDT(optionalClassNode.get());

                        // Add members to times() ObjectIDT
                        for(MemberNode mn: optionalClassNode.get().members)
                            timesObject.members.put(mn.declaration.name, instantiate(mn.declaration.type));

                        // Make a constructor
                        MethodCallStatementNode constructorNode = new MethodCallStatementNode();
                        constructorNode.methodName = "construct";
                        VariableReferenceNode numberVariable = new VariableReferenceNode();
                        numberVariable.name = mc.objectName.get();
                        constructorNode.parameters.add(numberVariable);

                        // Run the constructor
                        findConstructorAndRunIt(object, locals, constructorNode, timesObject);

                        // Find the "getNext()" method; throw an exception if there isn't one
                        MethodCallStatementNode methodCallStatementNode = new MethodCallStatementNode();
                        methodCallStatementNode.methodName = "getNext";

                        // it has 2 return values. The first is a boolean (was there another?), the second is a value
                        VariableReferenceNode bool = new VariableReferenceNode();
                        bool.name = "done";
                        VariableReferenceNode value = new VariableReferenceNode();
                        value.name = "value";
                        methodCallStatementNode.returnValues.add(bool);
                        methodCallStatementNode.returnValues.add(value);

                        // This will throw an exception if the method is not found
                        MethodDeclarationNode getNext = getMethodFromObject(timesObject, methodCallStatementNode, new ArrayList<>());

                        // if this is an iterator, call "getNext()"
                        var retVals = interpretMethodCall(Optional.of(timesObject), getNext, new LinkedList<>());

                        // while we're not done
                        while(((BooleanIDT)retVals.getFirst()).Value)
                        {
                            // If the loop has an assignment variable, populate it. For iterators, the "second value"
                            Optional<VariableReferenceNode> optionalVRN = ((LoopNode)statement).assignment;
                            if(optionalVRN.isPresent()) {
                                // Find the key with the same name and replace it with the new value
                                if (locals.containsKey(optionalVRN.get().name))
                                    locals.replace(optionalVRN.get().name, retVals.get(1));
                                else if (object.isPresent() && object.get().members.containsKey(optionalVRN.get().name))
                                    object.get().members.replace(optionalVRN.get().name, retVals.get(1));
                                    // if it doesn't exist throw exception
                                else throw new RuntimeException("Assignment not located in " + object);
                            }
                            // If our answer from above is "true", InterpretStatementBlock() on the body of the loop.
                            interpretStatementBlock(object, ((LoopNode)statement).statements, locals);

                            // call "getNext()"
                            retVals = interpretMethodCall(Optional.of(timesObject), getNext, new LinkedList<>());
                        }
                    }
                }
                // This is a boolean loop
                else
                {
                    // Call a method to interpret the loop
                    interpretBooleanLoop(object, locals, (LoopNode) statement);
                }
            }
            // If Node
            else if(statement instanceof IfNode)
            {
                // Evaluate() the condition
                InterpreterDataType idt = evaluate(locals, object, ((IfNode)statement).condition);
                if(!(idt instanceof BooleanIDT))
                    throw new RuntimeException("If condition "+((IfNode)statement).condition+" is not a boolean");
                // If true, InterpretStatementBlock() on the if's statements
                Optional<ElseNode> optionalElseNode = ((IfNode)statement).elseStatement;
                if(((BooleanIDT)idt).Value)
                    interpretStatementBlock(object, ((IfNode)statement).statements, locals);
                // If not AND there is an else, InterpretStatementBlock on the else body.
                else
                    optionalElseNode.ifPresent(elseNode -> interpretStatementBlock(object, elseNode.statements, locals));
            }
            else throw new RuntimeException(statement+" is not a valid statement");
        }
    }

    private void interpretBooleanLoop(Optional<ObjectIDT> object, HashMap<String, InterpreterDataType> locals, LoopNode statement) {
        // if this is a boolean loop, Evaluate() to get true or false.
        InterpreterDataType idt = evaluate(locals, object, statement.expression);
        if(!(idt instanceof BooleanIDT))
            throw new RuntimeException("Loop reference "+ statement.expression+" is not a boolean");
        boolean idtBoolean = ((BooleanIDT)idt).Value;
        while(idtBoolean) {
            // If the loop has an assignment variable, populate it, for boolean loops, the true/false.
            Optional<VariableReferenceNode> optionalVariableReferenceNode = statement.assignment;
            if (optionalVariableReferenceNode.isPresent()) {
                // Find the key with the same name and replace it with the new value
                if (locals.containsKey(optionalVariableReferenceNode.get().name))
                    locals.replace(optionalVariableReferenceNode.get().name, idt);
                else if (object.isPresent() && object.get().members.containsKey(optionalVariableReferenceNode.get().name))
                    object.get().members.replace(optionalVariableReferenceNode.get().name, idt);
                    // if it isn't found throw exception
                else throw new RuntimeException("Assignment not located in " + object);
            }
            interpretStatementBlock(object, statement.statements, locals);

            // if this is a boolean loop, Evaluate() to get true or false.
            idt = evaluate(locals, object, statement.expression);
            // Probably don't need to check again, but better safe than sorry
            if (!(idt instanceof BooleanIDT))
                throw new RuntimeException("Loop reference " + statement.expression + " is not a boolean");
            idtBoolean = ((BooleanIDT) idt).Value;
        }
    }

    /**
     *  evaluate() processes everything that is an expression - math, variables, boolean expressions.
     *  There is a good bit of recursion in here, since math and comparisons have left and right sides that need to be evaluated.
     *
     * See the How To Write an Interpreter document for examples
     * For each possible ExpressionNode, do the work to resolve it:
     * BooleanLiteralNode - create a new BooleanLiteralNode with the same value
     *      - Same for all of the basic data types
     * BooleanOpNode - Evaluate() left and right, then perform either and/or on the results.
     * CompareNode - Evaluate() both sides. Do good comparison for each data type
     * MathOpNode - Evaluate() both sides. If they are both numbers, do the math using the built-in operators. Also handle String + String as concatenation (like Java)
     * MethodCallExpression - call doMethodCall() and return the first value
     * VariableReferenceNode - call findVariable()
     * @param locals the local variables
     * @param object - the current object we are running
     * @param expression - some expression to evaluate
     * @return a value
     */
    private InterpreterDataType evaluate(HashMap<String, InterpreterDataType> locals, Optional<ObjectIDT> object, ExpressionNode expression) {
        // BooleanLiteralNode
        if(expression instanceof BooleanLiteralNode)
            return new BooleanIDT(((BooleanLiteralNode) expression).value);
        // CharLiteralNode
        else if(expression instanceof CharLiteralNode)
            return new CharIDT(((CharLiteralNode) expression).value);
        // NumericLiteralNode
        else if(expression instanceof NumericLiteralNode)
            return new NumberIDT(((NumericLiteralNode) expression).value);
        // StringLiteralNode
        else if(expression instanceof StringLiteralNode)
            return new StringIDT(((StringLiteralNode) expression).value);
        // BooleanOpNode
        else if(expression instanceof BooleanOpNode)
        {
            // Evaluate the left and right sides
            InterpreterDataType left = evaluate(locals, object, ((BooleanOpNode) expression).left);
            InterpreterDataType right = evaluate(locals, object, ((BooleanOpNode) expression).right);
            // We can only evaluate booleans with && and ||
            if(!(left instanceof BooleanIDT))
                throw new RuntimeException("Left type of "+left+" is not a BooleanIDT");
            else if(!(right instanceof BooleanIDT))
                throw new RuntimeException("Right type of "+right+" is not a BooleanIDT");
            else {
                // If the operation is and, evaluate left && right
                if(((BooleanOpNode)expression).op == BooleanOpNode.BooleanOperations.and)
                        return new BooleanIDT(((BooleanIDT)left).Value && ((BooleanIDT)right).Value);
                // Else it must be an || so evaluate left || right
                return new BooleanIDT(((BooleanIDT)left).Value || ((BooleanIDT)right).Value);
            }
        }
        // Not Op Node
        else if(expression instanceof NotOpNode)
        {
            // Evaluate the expression
            InterpreterDataType idt = evaluate(locals, object, ((NotOpNode)expression).left);
            // Throw exception if it's not a boolean
            if(!(idt instanceof BooleanIDT))
                throw new RuntimeException("Expression in "+idt+" is not a boolean");
            // Return the opposite of the value in the expression
            return new BooleanIDT(!(((BooleanIDT)idt).Value));
        }
        // CompareNode
        else if(expression instanceof CompareNode) {
            // Evaluate the left and right sides
            InterpreterDataType left = evaluate(locals, object, ((CompareNode) expression).left);
            InterpreterDataType right = evaluate(locals, object, ((CompareNode) expression).right);
            // Make sure types are the same on both sides
            // Left is String
            if (left instanceof StringIDT) {
                if (!(right instanceof StringIDT))
                    throw new RuntimeException("Right type of " + right + " is not a string");
            }
            // Left is Boolean
            else if (left instanceof BooleanIDT) {
                if (!(right instanceof BooleanIDT))
                    throw new RuntimeException("Right type of " + right + " is not a boolean");
            }
            // Left is a number
            else if (left instanceof NumberIDT)
            {
                if (!(right instanceof NumberIDT))
                    throw new RuntimeException("Right type of " + right + " is not a number");
            }
            // Left is a char
            else if(left instanceof CharIDT)
            {
                if (!(right instanceof CharIDT))
                    throw new RuntimeException("Right type of " + right + " is not a char");
            }
            // Left is a ReferenceIDT or ObjectIDT which we cannot use
            else throw new RuntimeException(left+" is not a valid type for a comparison");
            // Find the operation so there can be a proper comparison
            // ==
            if(((CompareNode)expression).op == CompareNode.CompareOperations.eq)
            {
                // Left is String
                if(left instanceof StringIDT)
                    return new BooleanIDT(((StringIDT)left).Value.equals(((StringIDT)right).Value));
                // Left is Boolean
                else if(left instanceof BooleanIDT)
                    return new BooleanIDT(((BooleanIDT)left).Value == ((BooleanIDT)right).Value);
                // Left is a number
                else if(left instanceof NumberIDT)
                    return new BooleanIDT(((NumberIDT)left).Value == ((NumberIDT)right).Value);
                // Left is a char
                else return new BooleanIDT(((CharIDT)left).Value == ((CharIDT)right).Value);
            }
            // !=
            else if(((CompareNode)expression).op == CompareNode.CompareOperations.ne)
            {
                // Left is String
                if(left instanceof StringIDT)
                    return new BooleanIDT(!(((StringIDT)left).Value.equals(((StringIDT)right).Value)));
                // Left is Boolean
                else if(left instanceof BooleanIDT)
                    return new BooleanIDT(((BooleanIDT)left).Value != ((BooleanIDT)right).Value);
                // Left is a number
                else if(left instanceof NumberIDT)
                    return new BooleanIDT(((NumberIDT)left).Value != ((NumberIDT)right).Value);
                // Left is a char
                else return new BooleanIDT(((CharIDT)left).Value != ((CharIDT)right).Value);
            }
            // >
            else if(((CompareNode)expression).op == CompareNode.CompareOperations.gt)
            {
                // Left is String
                if(left instanceof StringIDT)
                    // We can use compareTo for strings
                    return new BooleanIDT(((StringIDT) left).Value.compareTo(((StringIDT) right).Value) > 0);
                // Left is Boolean
                else if(left instanceof BooleanIDT)
                    // Booleans cannot be compared with >
                    throw new RuntimeException("Cannot compare booleans "+left+" and "+right+" with >");
                // Left is a number
                else if(left instanceof NumberIDT)
                    return new BooleanIDT(((NumberIDT)left).Value > ((NumberIDT)right).Value);
                // Left is a char
                else return new BooleanIDT(((CharIDT)left).Value > ((CharIDT)right).Value);
            }
            // <
            else if(((CompareNode)expression).op == CompareNode.CompareOperations.lt)
            {
                // Left is String
                if(left instanceof StringIDT)
                    // We can use compareTo for strings
                    return new BooleanIDT(((StringIDT) left).Value.compareTo(((StringIDT) right).Value) < 0);
                // Left is Boolean
                else if(left instanceof BooleanIDT)
                    // Booleans cannot be compared with <
                    throw new RuntimeException("Cannot compare booleans "+left+" and "+right+" with <");
                // Left is a number
                else if(left instanceof NumberIDT)
                    return new BooleanIDT(((NumberIDT)left).Value < ((NumberIDT)right).Value);
                // Left is a char
                else return new BooleanIDT(((CharIDT)left).Value < ((CharIDT)right).Value);
            }
            // <=
            else if(((CompareNode)expression).op == CompareNode.CompareOperations.le)
            {
                // Left is String
                if(left instanceof StringIDT)
                    // We can use compareTo for strings
                    return new BooleanIDT(((StringIDT) left).Value.compareTo(((StringIDT) right).Value) <= 0);
                // Left is Boolean
                else if(left instanceof BooleanIDT)
                    // Booleans cannot be compared with <=
                    throw new RuntimeException("Cannot compare booleans "+left+" and "+right+" with <=");
                // Left is a number
                else if(left instanceof NumberIDT)
                    return new BooleanIDT(((NumberIDT)left).Value <= ((NumberIDT)right).Value);
                // Left is a char
                else return new BooleanIDT(((CharIDT)left).Value <= ((CharIDT)right).Value);
            }
            // >=
            else
            {
                // Left is String
                if(left instanceof StringIDT)
                    // We can use compareTo for strings
                    return new BooleanIDT(((StringIDT) left).Value.compareTo(((StringIDT) right).Value) >= 0);
                // Left is Boolean
                else if(left instanceof BooleanIDT)
                    // Booleans cannot be compared with >
                    throw new RuntimeException("Cannot compare booleans "+left+" and "+right+" with >");
                // Left is a number
                else if(left instanceof NumberIDT)
                    return new BooleanIDT(((NumberIDT)left).Value >= ((NumberIDT)right).Value);
                // Left is a char
                else return new BooleanIDT(((CharIDT)left).Value >= ((CharIDT)right).Value);
            }
        }
        // MathOpNode
        else if(expression instanceof MathOpNode)
        {
            // Evaluate the left and right sides
            InterpreterDataType left = evaluate(locals, object, ((MathOpNode) expression).left);
            InterpreterDataType right = evaluate(locals, object, ((MathOpNode) expression).right);
            // Perform + on Strings or throw exception if not +
            if(left instanceof StringIDT && right instanceof StringIDT)
            {
                if(((MathOpNode)expression).op != MathOpNode.MathOperations.add)
                    throw new RuntimeException("Cannot perform "+((MathOpNode)expression).op+" on strings "+left+" and "+right);
                return new StringIDT(((StringIDT)left).Value+((StringIDT)right).Value);
            }
            else if(left instanceof NumberIDT && right instanceof NumberIDT)
            {
                // Check for the operation
                // +
                if(((MathOpNode)expression).op == MathOpNode.MathOperations.add)
                    return new NumberIDT(((NumberIDT)left).Value+((NumberIDT)right).Value);
                // -
                else if(((MathOpNode)expression).op == MathOpNode.MathOperations.subtract)
                    return new NumberIDT(((NumberIDT)left).Value-((NumberIDT)right).Value);
                // *
                else if(((MathOpNode)expression).op == MathOpNode.MathOperations.multiply)
                    return new NumberIDT(((NumberIDT)left).Value*((NumberIDT)right).Value);
                // /
                else if(((MathOpNode)expression).op == MathOpNode.MathOperations.divide)
                    return new NumberIDT(((NumberIDT)left).Value/((NumberIDT)right).Value);
                // %
                else return new NumberIDT(((NumberIDT)left).Value%((NumberIDT)right).Value);
            }
            else throw new RuntimeException(left+" and "+right+" incompatible with Math operation "+((MathOpNode)expression).op);
        }
        // MethodCallExpression
        else if(expression instanceof MethodCallExpressionNode)
        {
            // Convert the MethodCallExpression to a MethodCallStatement node
            MethodCallStatementNode mcs = new MethodCallStatementNode((MethodCallExpressionNode) expression);
            // Return the first value in the list
            return findMethodForMethodCallAndRunIt(object, locals, mcs).getFirst();
        }
        // VariableReferenceNode
        else if(expression instanceof VariableReferenceNode)
            // Return findVariable
            return findVariable((((VariableReferenceNode)expression).name), locals, object);
        // New Node
        else if(expression instanceof NewNode newNode)
        {
            // Find the class using the NewNode expression
            Optional<ClassNode> optionalClassNode = getClassByName(newNode.className);
            if(optionalClassNode.isEmpty()) throw new RuntimeException("new "+newNode+" used without an identified class ");
            ClassNode classNode = optionalClassNode.get();

            // Make a method call statement node to be used in findConstructorAndRunIt
            MethodCallStatementNode methodCallStatementNode = new MethodCallStatementNode();
            methodCallStatementNode.parameters = newNode.parameters;
            methodCallStatementNode.methodName = "construct";
            methodCallStatementNode.objectName = Optional.empty();

            // Create a new ObjectIDT and add members to it
            ObjectIDT newObj = new ObjectIDT(classNode);

            for(MemberNode memberNode: classNode.members)
            {
                InterpreterDataType dataType = instantiate(memberNode.declaration.type);
                newObj.members.put(memberNode.declaration.name, dataType);
            }

            // Call the constructor
            findConstructorAndRunIt(object, locals, methodCallStatementNode, newObj);

            // Return a referenceIDT to the new object
            ReferenceIDT referenceIDT = new ReferenceIDT();
            referenceIDT.Assign(newObj);
            return referenceIDT;
        }
        throw new IllegalArgumentException();
    }

    //              Utility Methods

    /**
     * Used when trying to find a match to a method call. Given a method declaration, does it match this methoc call?
     * We double check with the parameters, too, although in theory JUST checking the declaration to the call should be enough.
     *
     * Match names, parameter counts (both declared count vs method call and declared count vs value list), return counts.
     * If all of those match, consider the types (use TypeMatchToIDT).
     * If everything is OK, return true, else return false.
     * Note - if m is a built-in and isVariadic is true, skip all of the parameter validation.
     * @param m - the method declaration we are considering
     * @param mc - the method call we are trying to match
     * @param parameters - the parameter values for this method call
     * @return does this method match the method call?
     */
    private boolean doesMatch(MethodDeclarationNode m, MethodCallStatementNode mc, List<InterpreterDataType> parameters) {
        // Match names
        if(!m.name.equals(mc.methodName))
            return false;
        // Match return counts
//        else if(m.returns.size() != mc.returnValues.size())
//            return false;

        // if m is a built-in and isVariadic is true, skip all of the parameter validation.
        if(!(m instanceof BuiltInMethodDeclarationNode) || !(((BuiltInMethodDeclarationNode)m).isVariadic)) {
            // Match parameter counts (declared count vs value list)
            if(m.parameters.size() != parameters.size())
                return false;
            // Match parameter counts (declared count vs method call)
            else if(m.parameters.size() != mc.parameters.size())
                return false;
            // If all of those match, consider the types (use TypeMatchToIDT)
            for (int i = 0; i < m.parameters.size(); i++) {
                if (!typeMatchToIDT(m.parameters.get(i).type, parameters.get(i)))
                    return false;
            }
        }
        return true;
    }

    /**
     * Very similar to DoesMatch() except simpler - there are no return values, the name will always match.
     * @param c - a particular constructor
     * @param mc - the method call
     * @param parameters - the parameter values
     * @return does this constructor match the method call?
     */
    private boolean doesConstructorMatch(ConstructorNode c, MethodCallStatementNode mc, List<InterpreterDataType> parameters) {
        // Match parameter counts (declared count vs value list)
        if(c.parameters.size() != parameters.size())
            return false;
        // Match parameter counts (declared count vs method call)
        else if(c.parameters.size() != mc.parameters.size())
            return false;
        // If all of those match, consider the types (use TypeMatchToIDT)
        for (int i = 0; i < c.parameters.size(); i++) {
            if (!typeMatchToIDT(c.parameters.get(i).type, parameters.get(i)))
                return false;
        }
        return true;
    }

    /**
     * Used when we call a method to get the list of values for the parameters.
     *
     * for each parameter in the method call, call Evaluate() on the parameter to get an IDT and add it to a list
     * @param object - the current object
     * @param locals - the local variables
     * @param mc - a method call
     * @return the list of method values
     */
    private List<InterpreterDataType> getParameters(Optional<ObjectIDT> object, HashMap<String,InterpreterDataType> locals, MethodCallStatementNode mc) {
        List<InterpreterDataType> parameters = new ArrayList<InterpreterDataType>();
        // Iterate through mc.parameters, evaluate each expression node and add them to a list
        for(ExpressionNode expressionNode: mc.parameters)
            parameters.add(evaluate(locals, object, expressionNode));
        return parameters;
    }

    /**
     * Used when we have an IDT and we want to see if it matches a type definition
     * Commonly, when someone is making a function call - do the parameter values match the method declaration?
     *
     * If the IDT is a simple type (boolean, number, etc) - does the string type match the name of that IDT ("boolean", etc)
     * If the IDT is an object, check to see if the name matches OR the class has an interface that matches
     * If the IDT is a reference, check the inner (refered to) type
     * @param type the name of a data type (parameter to a method)
     * @param idt the IDT someone is trying to pass to this method
     * @return is this OK?
     */
    private boolean typeMatchToIDT(String type, InterpreterDataType idt) {
        // If the IDT is a String does the string type match "string"
        if(idt instanceof StringIDT)
            return type.equals("string");
        // If the IDT is a Char does the string type match "character"
        else if(idt instanceof CharIDT)
            return type.equals("char");
        // If the IDT is a Number does the string type match "number"
        else if(idt instanceof NumberIDT)
            return type.equals("number");
        // If the IDT is a Boolean does the string type match "boolean"
        else if(idt instanceof BooleanIDT)
            return type.equals("boolean");
        // If the IDT is an object, check to see if the name matches OR the class has an interface that matches
        else if(idt instanceof ObjectIDT)
        {
            // check to see if the name matches
            if(type.equals(((ObjectIDT)idt).astNode.name)) return true;

            // check to see if the class has an interface that matches
            for(String interfaceName: ((ObjectIDT)idt).astNode.interfaces)
                if(interfaceName.equals(type)) return true;
            return false;
        }
        // If the IDT is a reference, check the inner (refered to) type
        else if(idt instanceof ReferenceIDT)
            return ((ReferenceIDT) idt).refersTo.map(objectIDT -> (objectIDT.astNode.name.equals(type))).orElse(false);
        throw new RuntimeException("Unable to resolve type " + type);
    }

    /**
     * Find a method in an object that is the right match for a method call (same name, parameters match, etc. Uses doesMatch() to do most of the work)
     *
     * Given a method call, we want to loop over the methods for that class, looking for a method that matches (use DoesMatch) or throw
     * @param object - an object that we want to find a method on
     * @param mc - the method call
     * @param parameters - the parameter value list
     * @return a method or throws an exception
     */
    private MethodDeclarationNode getMethodFromObject(ObjectIDT object, MethodCallStatementNode mc, List<InterpreterDataType> parameters) {
        // clone is an exception since it will make a copy of the object
        if(mc.methodName.equals("clone"))
            return this.top.Classes.getFirst().methods.getLast();
        // Given a method call, we want to loop over the methods for that class
        for(MethodDeclarationNode mdn: object.astNode.methods)
            // If the method declaration node we found matches, return the method declaration node
            if(doesMatch(mdn, mc, parameters)) return mdn;
        // If we didn't find it throw an exception
        throw new RuntimeException("Unable to resolve method call " + mc);
    }

    /**
     * Find a class, given the name. Just loops over the TranNode's classes member, matching by name.
     *
     * Loop over each class in the top node, comparing names to find a match.
     * @param name Name of the class to find
     * @return either a class node or empty if that class doesn't exist
     */
    private Optional<ClassNode> getClassByName(String name) {
        for(ClassNode classNode: top.Classes)
        {
            if(classNode.name.equals(name))
                return Optional.of(classNode);
        }
        return Optional.empty();
    }

    /**
     * Given an execution environment (the current object, the current local variables), find a variable by name.
     *
     * @param name  - the variable that we are looking for
     * @param locals - the current method's local variables
     * @param object - the current object (so we can find members)
     * @return the IDT that we are looking for or throw an exception
     */
    private InterpreterDataType findVariable(String name, HashMap<String,InterpreterDataType> locals, Optional<ObjectIDT> object) {
        // See if the name can be found in locals
        if(locals.containsKey(name))
            return locals.get(name);
        // If not try and locate the name in the object's members
        else if(object.isPresent() && object.get().members.containsKey(name))
            return object.get().members.get(name);
        throw new RuntimeException("Unable to find variable " + name);
    }

    /**
     * Given a string (the type name), make an IDT for it.
     *
     * @param type The name of the type (string, number, boolean, character). Defaults to ReferenceIDT if not one of those.
     * @return an IDT with default values (0 for number, "" for string, false for boolean, ' ' for character)
     */
    private InterpreterDataType instantiate(String type) {
        // number
        if(type.equals("number"))
            return new NumberIDT(0);
        // string
        else if(type.equals("string"))
            return new StringIDT("");
        // boolean
        else if(type.equals("boolean"))
            return new BooleanIDT(false);
        // character
        else if(type.equals("character"))
            return new CharIDT('\0');
        // Else it should be a reference IDT
        else
        {
            ReferenceIDT referenceIDT = new ReferenceIDT();
            // Find a class node based on the type
            Optional<ClassNode> optionalClassNode = getClassByName(type);
            // If it returned an empty then this type is unknown and should throw an exception
            if(optionalClassNode.isEmpty())
                throw new RuntimeException("Unidentified type " + type);
            // Assign the ObjectIDT to the reference node and return it
            ObjectIDT newObjectIDT = new ObjectIDT(optionalClassNode.get());
            referenceIDT.Assign(newObjectIDT);
            return referenceIDT;
        }
    }
}

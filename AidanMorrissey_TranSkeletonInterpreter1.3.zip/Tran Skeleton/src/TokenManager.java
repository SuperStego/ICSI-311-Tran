import java.util.List;
import java.util.Optional;

public class TokenManager {
    List<Token> tokens;
    int previousColumnNumber;
    int previousLineNumber;

    public TokenManager(List<Token> tokens) {
        this.tokens = tokens;
    }

    public boolean done() {
        return tokens.isEmpty();
    }

    public Optional<Token> matchAndRemove(Token.TokenTypes t) {
        if(done())
            return Optional.empty();
        else if(t == tokens.getFirst().getType()) {
            setLineColumnNumber();
            return Optional.of(tokens.removeFirst());
        }
        return Optional.empty();
    }

    private void setLineColumnNumber() {
        previousColumnNumber = tokens.getFirst().getColumnNumber();
        previousLineNumber = tokens.getFirst().getLineNumber();
    }

    public Optional<Token> peek(int i) {
        if(done() || tokens.size() <= i)
            return Optional.empty();
        return Optional.of(tokens.get(i));
    }

    public boolean nextTwoTokensMatch(Token.TokenTypes t, Token.TokenTypes u) {
        if(done() || tokens.size() < 2)
            return false;
        return t == tokens.getFirst().getType() && u == tokens.get(1).getType();
    }

    public int getCurrentLine(){
        if(!done())
            return tokens.getFirst().getLineNumber();
        return previousLineNumber;
    }

    public int getCurrentColumnNumber(){
        if(!done())
            return tokens.getFirst().getColumnNumber();
        return previousColumnNumber;
    }
}

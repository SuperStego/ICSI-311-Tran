import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * This class will scan through a String input and place them in a LinkedList of tokens
 */
public class Lexer {
    private final TextManager textM; //Variable to hold a textManager for the String input
    private final HashMap<String,Token.TokenTypes> keywords; //Contains the possible keywords for tran
    private final HashMap<String, Token.TokenTypes> punctuation; //Contains the possible punctuation in tran
    private int lineNumber;
    private int characterPosition;
    private LinkedList<Token> ListOfTokens;
    private int spaceCount; //Used to find the number of consecutive spaces
    private int previousIndent; //Keeps track of the number of indents previously used

    /**
     * Constructor which creates a textManager to hold the input String
     * @param input - Text to be scanned through
     */
    public Lexer(String input) {
        textM = new TextManager(input);
        lineNumber = 0;
        characterPosition = 0;
        previousIndent = 0;

        //Fills the punctuation HashMap with the punctuation
        keywords = new HashMap<>();
        keywords.put("accessor", Token.TokenTypes.ACCESSOR);
        keywords.put("class", Token.TokenTypes.CLASS);
        keywords.put("implements", Token.TokenTypes.IMPLEMENTS);
        keywords.put("interface", Token.TokenTypes.INTERFACE);
        keywords.put("mutator", Token.TokenTypes.MUTATOR);
        keywords.put("loop", Token.TokenTypes.LOOP);
        keywords.put("if", Token.TokenTypes.IF);
        keywords.put("else", Token.TokenTypes.ELSE);
        keywords.put("true", Token.TokenTypes.TRUE);
        keywords.put("false", Token.TokenTypes.FALSE);
        keywords.put("new", Token.TokenTypes.NEW);
        keywords.put("private", Token.TokenTypes.PRIVATE);
        keywords.put("construct", Token.TokenTypes.CONSTRUCT);
        keywords.put("shared", Token.TokenTypes.SHARED);

        //Fills the punctuation HashMap with the punctuation
        punctuation = new HashMap<>();
        punctuation.put("=", Token.TokenTypes.ASSIGN);
        punctuation.put("(", Token.TokenTypes.LPAREN);
        punctuation.put(")", Token.TokenTypes.RPAREN);
        punctuation.put(":", Token.TokenTypes.COLON);
        punctuation.put(".",Token.TokenTypes.DOT);
        punctuation.put(",", Token.TokenTypes.COMMA);
        punctuation.put("+", Token.TokenTypes.PLUS);
        punctuation.put("-", Token.TokenTypes.MINUS);
        punctuation.put("*",Token.TokenTypes.TIMES);
        punctuation.put("/",Token.TokenTypes.DIVIDE);
        punctuation.put("%",Token.TokenTypes.MODULO);
        punctuation.put("==",Token.TokenTypes.EQUAL);
        punctuation.put("!=", Token.TokenTypes.NOTEQUAL);
        punctuation.put("<",Token.TokenTypes.LESSTHAN);
        punctuation.put("<=",Token.TokenTypes.LESSTHANEQUAL);
        punctuation.put(">",Token.TokenTypes.GREATERTHAN);
        punctuation.put(">=",Token.TokenTypes.GREATERTHANEQUAL);
        punctuation.put("&&",Token.TokenTypes.AND);
        punctuation.put("||",Token.TokenTypes.OR);
        punctuation.put("!",Token.TokenTypes.NOT);
        punctuation.put("\n",Token.TokenTypes.NEWLINE);
    }

    /**
     * This is the method that actually goes through the text and places the resulting
     * Tokens (words,numbers,punctuation) into a LinkedList of tokens
     * @return - List filled with tokens
     * @throws SyntaxErrorException - Can throw an exception through parsePunctuation() call if there is a
     * character unknown to the lexer
     */
    public List<Token> Lex() throws SyntaxErrorException {
        ListOfTokens = new LinkedList<>();
        Token newToken; //Variable to hold the newest token to be added to the List
        while (!textM.isAtEnd()){
            char aChar = textM.getCharacter(); //Selects the next character in the text to be analyzed
            characterPosition++;
            //Decimal points must be checked as a number in case of a number such as .45
            if(Character.isDigit(aChar) || (aChar == '.'&& Character.isDigit(textM.peekCharacter()))){
                newToken = parseNumber(aChar);
            }
            else if (Character.isLetter(aChar)){
                newToken = parseWord(aChar);
            }
            else if(aChar == '\''){
                aChar = textM.getCharacter();
                characterPosition++;
                if(textM.peekCharacter() != '\''){
                    throw new SyntaxErrorException("Invalid quoted char.",lineNumber,characterPosition);
                }
                else{
                    newToken = new Token(Token.TokenTypes.QUOTEDCHARACTER,lineNumber,characterPosition, ""+aChar);
                    textM.getCharacter();
                    characterPosition++;
                }
            }
            else if(aChar == '\"'){
                aChar = textM.peekCharacter();
                characterPosition++;
                newToken = parseQuotedString(aChar);
            }
            else {
                newToken = parsePunctuation(aChar);
            }
            if(newToken != null) { //Makes sure not to add any empty Tokens
                ListOfTokens.add(newToken);
            }
        }
        return ListOfTokens;
    }

    /**
     * When a quotation mark is seen in the text, this will iterate until a second quotation mark is found
     * @param aChar - char containing the quotation mark
     * @return - a Token with the resulting QuotedString token and a value containing
     * the chars within the quotation marks
     * @throws SyntaxErrorException - If a second quotation mark is not found
     */
    private Token parseQuotedString(char aChar) throws SyntaxErrorException {
        StringBuilder newWord = new StringBuilder();
        aChar = textM.getCharacter();
        characterPosition++;
        while(!textM.isAtEnd()&&aChar != '\"'){
            newWord.append(aChar);
            aChar = textM.getCharacter();
            characterPosition++;
        }
        if(aChar == '\"')
            return new Token(Token.TokenTypes.QUOTEDSTRING,lineNumber,characterPosition, newWord.toString());
        else
            throw new SyntaxErrorException("No closing quotation mark for quoted string",lineNumber,characterPosition);
    }

    /**
     * Method which adds letter to a word until a character which isn't a letter is found
     * @param aChar - char that holds the current Character being analyzed
     * @return - A token holding the word
     */
    private Token parseWord(char aChar) {
        StringBuilder newWord = new StringBuilder();
        newWord.append(aChar); //This character was already found to be a letter
        //Makes sure not to select the next character unless
        //it's a letter (would not be reachable in the rest of the code)
        while(!textM.isAtEnd() && Character.isLetter(textM.peekCharacter())){
            aChar = textM.getCharacter();
            characterPosition++;
            newWord.append(aChar);
        }
        String word = newWord.toString();
        //Checks if new word is a tran keyword
        if(keywords.containsKey(word)){
            return new Token(keywords.get(word),lineNumber,characterPosition);
        }
        else {
            return new Token(Token.TokenTypes.WORD, lineNumber, characterPosition, newWord.toString());
        }
    }

    /**
     * Method which adds numbers (and decimals) to a String until either a non-number is found
     * or more than one decimal has been placed in the String
     * @param aChar - char that holds the current character to be analyzed
     * @return - A token with the resulting number
     */
    private Token parseNumber(char aChar){
        boolean seenDot = false; //Keeps track of whether a decimal point has been seen already
        StringBuilder newWord = new StringBuilder(); //Using StringBuilder since it wants to concatenate
        //without creating a new String every time
        if(aChar == '.') //Fixes an error where if a decimal point is the first character
            //The program doesn't remember it's seen a decimal before
            seenDot = true;
        newWord.append(aChar); //Already seen to be a number
        while(!textM.isAtEnd() && ((Character.isDigit(textM.peekCharacter()) || (textM.peekCharacter() == '.' && !seenDot)))){
            aChar = textM.getCharacter();
            characterPosition++;
            if(aChar == '.'){ //If there is a decimal point, checks if there has already been one
                seenDot = true;
            }
            newWord.append(aChar);
        }
        return new Token(Token.TokenTypes.NUMBER, lineNumber, characterPosition, newWord.toString());
    }

    /**
     * Checks what kind of punctuation has been passed through and creates a token with the correct type
     * If the punctuation is unusable, throws an error
     * @param aChar - the character to be analyzed
     * @return - A token which holds the punctuation
     * @throws SyntaxErrorException - If character is unusable by the lexer
     */
    private Token parsePunctuation(char aChar) throws SyntaxErrorException {
        Token newToken = null;
        if(punctuation.containsKey(""+aChar+textM.peekCharacter())){
            newToken = new Token(punctuation.get(""+aChar+textM.peekCharacter()),lineNumber,characterPosition);
            textM.getCharacter();
            characterPosition++;
        }
        else if(punctuation.containsKey(""+aChar)) {
            ListOfTokens.add(new Token(punctuation.get("" + aChar), lineNumber, characterPosition));
            if (aChar == '\n') {
                lineNumber++;
                characterPosition = 0;
                checkIndent();
            }
        }
        else if(aChar ==' '){
            if(ListOfTokens.getLast().getType().equals(Token.TokenTypes.NEWLINE)){
                checkIndent();
            }
        }
        else
            throw new SyntaxErrorException("Syntax error occurred",lineNumber,characterPosition);
        return newToken;
    }

    /**
     * Checks the indent in this line compared to the last one
     */
    public void checkIndent(){
        spaceCount = 1;
        int extraIndents = 0; //Sees how many more/less indented this line is to the previous line
        while(textM.peekCharacter()==' '){
            spaceCount++;
            textM.getCharacter();
            characterPosition++;
        }
        if(spaceCount > previousIndent*4) {
            //Counts how many extra indents there are in this line
            while (spaceCount / 4 > previousIndent) {
                extraIndents++;
                spaceCount = spaceCount - 4;
            }
            //For every extra indent, an indent token is added to the list
            for(int i = 0; i < extraIndents; i++){
                ListOfTokens.add(new Token(Token.TokenTypes.INDENT,lineNumber,characterPosition));
                previousIndent++;
            }
        }
        else {
            //Counts how many fewer indents there are in this line
            while (spaceCount / 4 < previousIndent) {
                extraIndents--;
                spaceCount = spaceCount + 4;
            }
            //For every extra dedent, a dedent token is added to the list
            for(int i = 0; i > extraIndents; i--){
                ListOfTokens.add(new Token(Token.TokenTypes.DEDENT,lineNumber,characterPosition));
                previousIndent--;
            }
        }
    }
}

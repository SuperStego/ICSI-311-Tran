import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;

public class Lexer1Tests {

    @Test
    public void SimpleLexerTest() {
        var l = new Lexer("ab cd ef gh");
        try {
            var res = l.Lex();
            Assertions.assertEquals(4, res.size());
            Assertions.assertEquals("ab", res.get(0).getValue());
            Assertions.assertEquals("cd", res.get(1).getValue());
            Assertions.assertEquals("ef", res.get(2).getValue());
            Assertions.assertEquals("gh", res.get(3).getValue());
            for (var result : res)
                Assertions.assertEquals(Token.TokenTypes.WORD, result.getType());
        }
        catch (Exception e) {
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void MultilineLexerTest() {
        var l = new Lexer("ab cd ef gh\nasdjkdsajkl\ndsajkdsa asdjksald dsajhkl \n");
        try {
            var res = l.Lex();
            Assertions.assertEquals(11, res.size());
            Assertions.assertEquals("ab", res.get(0).getValue());
            Assertions.assertEquals("cd", res.get(1).getValue());
            Assertions.assertEquals("ef", res.get(2).getValue());
            Assertions.assertEquals("gh", res.get(3).getValue());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(4).getType());
            Assertions.assertEquals("asdjkdsajkl", res.get(5).getValue());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(6).getType());
            Assertions.assertEquals("dsajkdsa", res.get(7).getValue());
            Assertions.assertEquals("asdjksald", res.get(8).getValue());
            Assertions.assertEquals("dsajhkl", res.get(9).getValue());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(10).getType());
        }
        catch (Exception e) {
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void NotEqualsTest() {
        var l = new Lexer("!=");
        try {
            var res = l.Lex();
            Assertions.assertEquals(1, res.size());
        }
        catch (Exception e) {
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void TwoCharacterTest() {
        var l = new Lexer(">= > <= < = == !=");
        try {
            var res = l.Lex();
            Assertions.assertEquals(7, res.size());
            Assertions.assertEquals(Token.TokenTypes.GREATERTHANEQUAL, res.get(0).getType());
            Assertions.assertEquals(Token.TokenTypes.GREATERTHAN, res.get(1).getType());
            Assertions.assertEquals(Token.TokenTypes.LESSTHANEQUAL, res.get(2).getType());
            Assertions.assertEquals(Token.TokenTypes.LESSTHAN, res.get(3).getType());
            Assertions.assertEquals(Token.TokenTypes.ASSIGN, res.get(4).getType());
            Assertions.assertEquals(Token.TokenTypes.EQUAL, res.get(5).getType());
            Assertions.assertEquals(Token.TokenTypes.NOTEQUAL, res.get(6).getType());
        }
        catch (Exception e) {
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void MixedTest() {
        var l = new Lexer("word 1.2 : ( )");
        try {
            var res = l.Lex();
            Assertions.assertEquals(5, res.size());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(0).getType());
            Assertions.assertEquals("word", res.get(0).getValue());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(1).getType());
            Assertions.assertEquals("1.2", res.get(1).getValue());
            Assertions.assertEquals(Token.TokenTypes.COLON, res.get(2).getType());
            Assertions.assertEquals(Token.TokenTypes.LPAREN, res.get(3).getType());
            Assertions.assertEquals(Token.TokenTypes.RPAREN, res.get(4).getType());
        }
        catch (Exception e) {
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void TwoDecimalTest(){
        var l = new Lexer("3.4.5");
        try{
            var res = l.Lex();
            Assertions.assertEquals(2, res.size());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(0).getType());
            Assertions.assertEquals("3.4",res.get(0).getValue());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(1).getType());
            Assertions.assertEquals(".5",res.get(1).getValue());
        } catch (Exception e) {
            Assertions.fail("exception occurred: "+ e.getMessage());
        }
    }

    @Test
    public void ManyDecimalTest(){
        var l = new Lexer("3.4.5.67.891");
        try{
            var res = l.Lex();
            Assertions.assertEquals(4, res.size());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(0).getType());
            Assertions.assertEquals("3.4",res.get(0).getValue());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(1).getType());
            Assertions.assertEquals(".5",res.get(1).getValue());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(2).getType());
            Assertions.assertEquals(".67", res.get(2).getValue());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(3).getType());
            Assertions.assertEquals(".891", res.get(3).getValue());
        } catch(Exception e) {
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }
    @Test
    public void MaxWordTest(){
        var l = new Lexer("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz   ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz");
        try{
            var res = l.Lex();
            Assertions.assertEquals(2, res.size());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(0).getType());
            Assertions.assertEquals("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", res.get(0).getValue());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(1).getType());
            Assertions.assertEquals("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", res.get(1).getValue());
        }catch(Exception e){
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void WordsSeparatedByPunctuationTest(){
        var l = new Lexer("Giant,Ant!People\nWhat==GROSS");
        try{
            var res = l.Lex();
            Assertions.assertEquals(9, res.size());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(0).getType());
            Assertions.assertEquals("Giant", res.get(0).getValue());
            Assertions.assertEquals(Token.TokenTypes.COMMA, res.get(1).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(2).getType());
            Assertions.assertEquals("Ant", res.get(2).getValue());
            Assertions.assertEquals(Token.TokenTypes.NOT, res.get(3).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(4).getType());
            Assertions.assertEquals("People", res.get(4).getValue());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(5).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(6).getType());
            Assertions.assertEquals("What", res.get(6).getValue());
            Assertions.assertEquals(Token.TokenTypes.EQUAL, res.get(7).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(8).getType());
            Assertions.assertEquals("GROSS", res.get(8).getValue());
        }catch(Exception e){
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void MoreDecimalNumberTest(){
        var l = new Lexer(".45 4.37 87.57");
        try{
            var res = l.Lex();
            Assertions.assertEquals(3, res.size());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(0).getType());
            Assertions.assertEquals(".45", res.get(0).getValue());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(1).getType());
            Assertions.assertEquals("4.37", res.get(1).getValue());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(2).getType());
            Assertions.assertEquals("87.57", res.get(2).getValue());
        } catch(Exception e){
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void AllTogetherNowTest(){
        var l = new Lexer("WE!===LOVE13.45NUmBERS(");
        try {
            var res = l.Lex();
            Assertions.assertEquals(7, res.size());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(0).getType());
            Assertions.assertEquals("WE", res.get(0).getValue());
            Assertions.assertEquals(Token.TokenTypes.NOTEQUAL, res.get(1).getType());
            Assertions.assertEquals(Token.TokenTypes.EQUAL, res.get(2).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(3).getType());
            Assertions.assertEquals("LOVE", res.get(3).getValue());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(4).getType());
            Assertions.assertEquals("13.45", res.get(4).getValue());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(5).getType());
            Assertions.assertEquals("NUmBERS", res.get(5).getValue());
            Assertions.assertEquals(Token.TokenTypes.LPAREN, res.get(6).getType());
        } catch(Exception e){
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void UnknownPunctuationTest(){
        var l = new Lexer("&");
        try{
            l.Lex();
            Assertions.fail("Error not found");
        }catch(SyntaxErrorException e){}
        catch(Exception e){
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void EmptyTest(){
        var l = new Lexer("");
        try{
            l.Lex();
        }
        catch(Exception e){
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }
}

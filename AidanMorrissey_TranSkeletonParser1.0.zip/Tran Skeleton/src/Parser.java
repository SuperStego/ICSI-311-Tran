import AST.*;

import java.util.List;
import java.util.Optional;

public class Parser {
    private final TokenManager tokens;
    private TranNode root;

    public Parser(TranNode top, List<Token> tokens) {
        root = top;
        this.tokens = new TokenManager(tokens);
    }

    // Tran = { Class | Interface }
    public void Tran() throws SyntaxErrorException {
        if(!tokens.matchAndRemove(Token.TokenTypes.INTERFACE).equals(Optional.empty()))
            root.Interfaces.add(Interface().get());
    }

    //Interface = Name [ { Implements Interface } ] NewLine Indent [ { ( Methods | Method ) [ NewLine ] } ] [ Dedent ]
    private Optional<InterfaceNode> Interface() throws SyntaxErrorException {
        InterfaceNode interfaceNode = new InterfaceNode();
        //Name [{Implements Interface}]
        if(tokens.matchAndRemove(Token.TokenTypes.WORD).equals(Optional.empty()))
            throw new SyntaxErrorException("No Interface Name", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        if(!tokens.matchAndRemove(Token.TokenTypes.IMPLEMENTS).equals(Optional.empty()))
            if(!tokens.done()&&tokens.matchAndRemove(Token.TokenTypes.WORD).equals(Optional.empty()))
                throw new SyntaxErrorException("Doesn't implement an interface", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        if(!tokens.done()) {
            //NewLine
            RequireNewLine();
            if (!tokens.done()) {
                //Indent
                if (tokens.matchAndRemove(Token.TokenTypes.INDENT).equals(Optional.empty()))
                    throw new SyntaxErrorException("Indent Expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
                // [ NewLine | NewLines ]
                if(tokens.peek(0).get().getType().equals(Token.TokenTypes.NEWLINE))
                    RequireNewLine();
                // { Methods | Method }
                do {
                    interfaceNode.methods.add(MethodHeader().get());
                    //If not end of class Then NewLine
                    if (!tokens.done() && !tokens.peek(0).get().getType().equals(Token.TokenTypes.DEDENT))
                        RequireNewLine();
                }while(!tokens.peek(0).get().getType().equals(Token.TokenTypes.DEDENT));
            }
            //If not end of class Then Dedent
            while (!tokens.matchAndRemove(Token.TokenTypes.DEDENT).equals(Optional.empty())) ;
        }
        return Optional.of(interfaceNode);
    }

    // MethodHeader = [ Private ] [ Shared ] Name LParen [ { VariableDeclaration | VariableDeclaration } ]
    // RParen [ Colon { VariableDeclarations | VariableDeclaration }
    private Optional<MethodHeaderNode> MethodHeader() throws SyntaxErrorException {
        MethodHeaderNode methodHeaderNode = new MethodHeaderNode();
        // [ Private ] [ Shared ]
        tokens.matchAndRemove(Token.TokenTypes.PRIVATE);
        tokens.matchAndRemove(Token.TokenTypes.SHARED);
        //Name
        if(!tokens.peek(0).get().getType().equals(Token.TokenTypes.WORD))
            throw new SyntaxErrorException("Missing Method Header Name", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        methodHeaderNode.name = tokens.matchAndRemove(Token.TokenTypes.WORD).get().getValue();
        //LParen
        if(tokens.matchAndRemove(Token.TokenTypes.LPAREN).equals(Optional.empty()))
            throw new SyntaxErrorException("Missing Left Parenthesis",tokens.getCurrentLine(),tokens.getCurrentColumnNumber());
        // [ { VariableDeclarations | VariableDeclaration } ]
        if(tokens.peek(0).get().getType().equals(Token.TokenTypes.WORD))
            methodHeaderNode = VariableDeclarations(methodHeaderNode,true).get();
        // RParen
        if(tokens.matchAndRemove(Token.TokenTypes.RPAREN).equals(Optional.empty()))
            throw new SyntaxErrorException("Missing Right Parenthesis",tokens.getCurrentLine(),tokens.getCurrentColumnNumber());
        // [ Colon { VariableDeclarations | VariableDeclaration } ]
        if(!tokens.matchAndRemove(Token.TokenTypes.COLON).equals(Optional.empty()))
            methodHeaderNode = VariableDeclarations(methodHeaderNode,false).get();
        return Optional.of(methodHeaderNode);
    }

    /*paramOrReturn is true for parameters and false for return values*/
    // VariableDeclarations = { VariableDeclaration | VariableDeclaration }
    private Optional<MethodHeaderNode> VariableDeclarations(MethodHeaderNode methodHeaderNode, boolean paramOrReturn) throws SyntaxErrorException {
        // { VariableDeclaration }
        // ( Word Word ) First variable must have a type and name
        if(!tokens.matchAndRemove(Token.TokenTypes.WORD).equals(Optional.empty())) {
            if (tokens.matchAndRemove(Token.TokenTypes.WORD).equals(Optional.empty()))
                throw new SyntaxErrorException("Variable Name Expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        }
        // { VariableDeclaration }
        while(!tokens.matchAndRemove(Token.TokenTypes.COMMA).equals(Optional.empty())) {
            if (paramOrReturn)
                methodHeaderNode.parameters.add(VariableDeclaration().get());
            else methodHeaderNode.returns.add(VariableDeclaration().get());
        }
        return Optional.of(methodHeaderNode);
    }

    // VariableDeclaration = ( Data Type Name | Name )
    private Optional<VariableDeclarationNode> VariableDeclaration() throws SyntaxErrorException {
        VariableDeclarationNode variableDeclarationNode = new VariableDeclarationNode();
        // ( Identifier | Name )
        Optional<Token> result1 = tokens.matchAndRemove(Token.TokenTypes.WORD);
        if(result1.equals(Optional.empty()))
            throw new SyntaxErrorException("Missing Variable Identifier or Name", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        Optional<Token> result2 = tokens.matchAndRemove(Token.TokenTypes.WORD); //Possible name if result1 is Identifier
        // If Identifier then Name
        if(!result2.equals(Optional.empty())) {
            variableDeclarationNode.type = result1.get().getValue();
            variableDeclarationNode.name = result2.get().getValue();
        }
        else variableDeclarationNode.name = result1.get().getValue();
        return Optional.of(variableDeclarationNode);
    }

    // NewLines = { NewLine | NewLines }
    private void RequireNewLine() throws SyntaxErrorException {
        if(tokens.matchAndRemove(Token.TokenTypes.NEWLINE).equals(Optional.empty()))
            throw new SyntaxErrorException("New Line Expected",tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        else while(!tokens.matchAndRemove(Token.TokenTypes.NEWLINE).equals(Optional.empty()));
    }
}
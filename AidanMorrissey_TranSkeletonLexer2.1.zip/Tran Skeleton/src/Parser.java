import AST.*;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

public class Parser {
    public Parser(TranNode top, List<Token> tokens) {
    }

    // Tran = { Class | Interface }
    public void Tran() throws SyntaxErrorException {
    }
}
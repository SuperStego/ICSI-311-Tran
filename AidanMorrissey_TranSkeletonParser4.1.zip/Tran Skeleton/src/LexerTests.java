import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class LexerTests {
    @Test
    public void QuotationExceptionTest(){
        var l = new Lexer("\"Potato12.25==");
        try{
            l.Lex();
            Assertions.fail("Exception not found ");
        }catch(SyntaxErrorException e){}
        catch(Exception e){
            Assertions.fail("Incorrect exception occurred: " + e.getMessage());
        }
    }

    @Test
    public void LetsTryABlock(){
        var l = new Lexer("loop peopleDoing\n" +
                "    if(!doSomethingWithAPersonObject)\n" +
                "         loop(n>=25.25)\n" +
                "            IDontKnow()\n" +
                "            n = n - 1\n" +
                "    else\n" +
                "        doSomethingElse()");
        try{
            var res = l.Lex();
            Assertions.assertEquals(37, res.size());
            Assertions.assertEquals(Token.TokenTypes.LOOP, res.get(0).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(1).getType());
            Assertions.assertEquals("peopleDoing", res.get(1).getValue());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(2).getType());
            Assertions.assertEquals(Token.TokenTypes.INDENT, res.get(3).getType());
            Assertions.assertEquals(Token.TokenTypes.IF, res.get(4).getType());
            Assertions.assertEquals(Token.TokenTypes.LPAREN, res.get(5).getType());
            Assertions.assertEquals(Token.TokenTypes.NOT, res.get(6).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(7).getType());
            Assertions.assertEquals("doSomethingWithAPersonObject", res.get(7).getValue());
            Assertions.assertEquals(Token.TokenTypes.RPAREN, res.get(8).getType());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(9).getType());
            Assertions.assertEquals(Token.TokenTypes.INDENT, res.get(10).getType());
            Assertions.assertEquals(Token.TokenTypes.LOOP, res.get(11).getType());
            Assertions.assertEquals(Token.TokenTypes.LPAREN, res.get(12).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(13).getType());
            Assertions.assertEquals("n",res.get(13).getValue());
            Assertions.assertEquals(Token.TokenTypes.GREATERTHANEQUAL, res.get(14).getType());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(15).getType());
            Assertions.assertEquals("25.25",res.get(15).getValue());
            Assertions.assertEquals(Token.TokenTypes.RPAREN, res.get(16).getType());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(17).getType());
            Assertions.assertEquals(Token.TokenTypes.INDENT, res.get(18).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(19).getType());
            Assertions.assertEquals("IDontKnow", res.get(19).getValue());
            Assertions.assertEquals(Token.TokenTypes.LPAREN, res.get(20).getType());
            Assertions.assertEquals(Token.TokenTypes.RPAREN, res.get(21).getType());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(22).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(23).getType());
            Assertions.assertEquals("n", res.get(23).getValue());
            Assertions.assertEquals(Token.TokenTypes.ASSIGN, res.get(24).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(25).getType());
            Assertions.assertEquals("n", res.get(25).getValue());
            Assertions.assertEquals(Token.TokenTypes.MINUS, res.get(26).getType());
            Assertions.assertEquals(Token.TokenTypes.NUMBER, res.get(27).getType());
            Assertions.assertEquals("1", res.get(27).getValue());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(28).getType());
            Assertions.assertEquals(Token.TokenTypes.DEDENT, res.get(29).getType());
            Assertions.assertEquals(Token.TokenTypes.DEDENT, res.get(30).getType());
            Assertions.assertEquals(Token.TokenTypes.ELSE, res.get(31).getType());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(32).getType());
            Assertions.assertEquals(Token.TokenTypes.INDENT, res.get(33).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(34).getType());
            Assertions.assertEquals("doSomethingElse", res.get(34).getValue());
            Assertions.assertEquals(Token.TokenTypes.LPAREN, res.get(35).getType());
            Assertions.assertEquals(Token.TokenTypes.RPAREN, res.get(36).getType());
        }catch(Exception e){
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void QuotedCharacterTest(){
        var l = new Lexer("\'a\'\'=\'");
        try{
            var res = l.Lex();
            Assertions.assertEquals(Token.TokenTypes.QUOTEDCHARACTER, res.get(0).getType());
            Assertions.assertEquals("a", res.get(0).getValue());
            Assertions.assertEquals(Token.TokenTypes.QUOTEDCHARACTER, res.get(1).getType());
            Assertions.assertEquals("=", res.get(1).getValue());
        }catch(Exception e){
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void IncorrectQuotedCharacterTest(){
        var l = new Lexer("\'a");
        try{
            l.Lex();
            Assertions.fail("Exception not thrown");
        } catch (SyntaxErrorException e) {}
        catch(Exception e){
            Assertions.fail("Correct exception not thrown");
        }
    }

    @Test
    public void DoubleIndentTest(){
        var l = new Lexer("something\n" +
                "        somethingElse");
        try {
            var res = l.Lex();
            Assertions.assertEquals(5, res.size());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(0).getType());
            Assertions.assertEquals("something", res.get(0).getValue());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(1).getType());
            Assertions.assertEquals(Token.TokenTypes.INDENT, res.get(2).getType());
            Assertions.assertEquals(Token.TokenTypes.INDENT, res.get(3).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(4).getType());
            Assertions.assertEquals("somethingElse", res.get(4).getValue());
        } catch (Exception e) {
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void MoreIndentTest(){
        var l = new Lexer("        no\n" +
                "    yes\n" +
                "        doubleYes\n");
        try{
            var res = l.Lex();
            Assertions.assertEquals(10, res.size());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(0).getType());
            Assertions.assertEquals("no", res.get(0).getValue());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(1).getType());
            Assertions.assertEquals(Token.TokenTypes.INDENT, res.get(2).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(3).getType());
            Assertions.assertEquals("yes", res.get(3).getValue());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(4).getType());
            Assertions.assertEquals(Token.TokenTypes.INDENT, res.get(5).getType());
            Assertions.assertEquals(Token.TokenTypes.WORD, res.get(6).getType());
            Assertions.assertEquals("doubleYes", res.get(6).getValue());
            Assertions.assertEquals(Token.TokenTypes.NEWLINE, res.get(7).getType());
            Assertions.assertEquals(Token.TokenTypes.DEDENT, res.get(8).getType());
            Assertions.assertEquals(Token.TokenTypes.DEDENT, res.get(9).getType());
        }catch(Exception e){
            Assertions.fail("exception occurred: " +  e.getMessage());
        }
    }

    @Test
    public void BrokenParserTest() throws SyntaxErrorException {
        var l = new Lexer("interface someName\r\n\tupdateClock()\r\n\tsquare() : number s");
        var res = l.Lex();
        Assertions.assertEquals(Token.TokenTypes.NEWLINE,res.get(2).getType());
    }
}

public class TextManager {

    private int position; //Holds the current position in the text
    private String text; //Holds the text

    /**
     * Constructor
     * @param input - The text
     */
    public TextManager(String input) {
        position = 0;
        text = input;
    }

    /**
     * @return - True if the position is at the end of the text, false otherwise
     */
    public boolean isAtEnd() {
        return position >= text.length();
    }

    /**
     * @return - The character that will be selected on the next getCharacter()
     */
    public char peekCharacter() {
        if(position >= text.length()){
            return '\0';//Returns a null value to avoid IndexOutOfBoundsError
        }
        return text.charAt(position);
    }

    /**
     * @param distance - How many positions ahead the character should be returned
     * @return - The character a certain distance away from the current position
     */
    public char peekCharacter(int distance) {
        if((distance + position) >= text.length()) {
            return '\0';//Returns a null value to avoid IndexOutOfBounds error
        }
        return text.charAt(position + distance);
    }

    /**
     * Returns the next character and increments the position
     * @return - The next character in the text
     */
    public char getCharacter() {
        return text.charAt(position++);
    }
}

import AST.*;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

public class Parser {
    private final TokenManager tokens;
    private final TranNode root;

    public Parser(TranNode top, List<Token> tokens) {
        root = top;
        this.tokens = new TokenManager(tokens);
    }

    // Tran = { Class | Interface }
    public void Tran() throws SyntaxErrorException {
        int numClasses = 0;
        while(!tokens.done()) {
            if (!tokens.matchAndRemove(Token.TokenTypes.INTERFACE).equals(Optional.empty())) {
                Optional<InterfaceNode> optionalInterfaceNode = Interface();
                optionalInterfaceNode.ifPresent(interfaceNode -> root.Interfaces.add(interfaceNode));
            }
            else if (!tokens.matchAndRemove(Token.TokenTypes.CLASS).equals(Optional.empty())) {
                if(++numClasses > 1)
                    throw new SyntaxErrorException("Cannot have more than one class",tokens.getCurrentLine(),tokens.getCurrentColumnNumber());
                Optional<ClassNode> optionalClassNode = Class();
                optionalClassNode.ifPresent(classNode -> root.Classes.add(classNode));
            }
            else if(tokens.peek(0).get().getType().equals(Token.TokenTypes.NEWLINE))
                RequireNewLine();
            else if(tokens.peek(0).isPresent() && tokens.peek(0).get().getType().equals(Token.TokenTypes.DEDENT))
                tokens.matchAndRemove(Token.TokenTypes.DEDENT);
            else throw new SyntaxErrorException("Class or Interface Expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        }
    }

    // Interface = "interface" Identifier NEWLINE INDENT {MethodHeader NEWLINE } DEDENT
    private Optional<InterfaceNode> Interface() throws SyntaxErrorException {
        InterfaceNode interfaceNode = new InterfaceNode();
        //Identifier
        Optional<Token> identifier = tokens.matchAndRemove(Token.TokenTypes.WORD);
        if(identifier.isEmpty())
            throw new SyntaxErrorException("No Interface Name", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        interfaceNode.name = identifier.get().getValue();
        //NewLine
        RequireNewLine();
        //Indent
        if(tokens.matchAndRemove(Token.TokenTypes.INDENT).equals(Optional.empty()))
            throw new SyntaxErrorException("Indent Expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        // { MethodHeader NEWLINE }
        do {
            Optional<MethodHeaderNode> optionalMethodHeaderNode = MethodHeader();
            optionalMethodHeaderNode.ifPresent(methodHeaderNode -> interfaceNode.methods.add(methodHeaderNode));
            //If not end of class Then NewLine
            if (tokens.peek(0).isPresent() && !tokens.peek(0).get().getType().equals(Token.TokenTypes.DEDENT))
                RequireNewLine();
        }while(!tokens.peek(0).get().getType().equals(Token.TokenTypes.DEDENT));
        //DEDENT
        if(tokens.matchAndRemove(Token.TokenTypes.DEDENT).equals(Optional.empty()))
            throw new SyntaxErrorException("Dedent Expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        return Optional.of(interfaceNode);
    }

    // MethodHeader = Identifier "(" VariableDeclarations ")"
    // [ ":" VariableDeclaration { "," VariableDeclaration } ]
    private Optional<MethodHeaderNode> MethodHeader() throws SyntaxErrorException {
        MethodHeaderNode methodHeaderNode = new MethodHeaderNode();
        //Identifier
        if(tokens.peek(0).isPresent() && !tokens.peek(0).get().getType().equals(Token.TokenTypes.WORD))
            throw new SyntaxErrorException("Missing Method Header Name", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        Optional<Token> methodHeaderName = tokens.matchAndRemove(Token.TokenTypes.WORD);
        if(methodHeaderName.isPresent())
            methodHeaderNode.name = methodHeaderName.get().getValue();
        else throw new SyntaxErrorException("No method header name", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        // LPAREN
        if(tokens.matchAndRemove(Token.TokenTypes.LPAREN).equals(Optional.empty()))
            throw new SyntaxErrorException("Missing Left Parenthesis",tokens.getCurrentLine(),tokens.getCurrentColumnNumber());
        // VariableDeclarations
        LinkedList<VariableDeclarationNode> variableDeclarationsList;
        if(tokens.peek(0).get().getType().equals(Token.TokenTypes.WORD)) {
            Optional<LinkedList<VariableDeclarationNode>> optionalVariableDeclarationNodes = VariableDeclarations();
            if(optionalVariableDeclarationNodes.isPresent()) {
                variableDeclarationsList = optionalVariableDeclarationNodes.get();
                while (!variableDeclarationsList.isEmpty())
                    methodHeaderNode.parameters.add(variableDeclarationsList.removeFirst());
            }
        }
        // RPAREN
        if(tokens.matchAndRemove(Token.TokenTypes.RPAREN).equals(Optional.empty()))
            throw new SyntaxErrorException("Missing Right Parenthesis",tokens.getCurrentLine(),tokens.getCurrentColumnNumber());
        // [ ":" VariableDeclaration { "," VariableDeclaration } ]
        if(!tokens.matchAndRemove(Token.TokenTypes.COLON).equals(Optional.empty())) {
            Optional<LinkedList<VariableDeclarationNode>> optionalVariableDeclarationNodes = VariableDeclarations();
            if(optionalVariableDeclarationNodes.isPresent()) {
                variableDeclarationsList = optionalVariableDeclarationNodes.get();
                while (!variableDeclarationsList.isEmpty())
                    methodHeaderNode.returns.add(variableDeclarationsList.removeFirst());
            }
        }
        return Optional.of(methodHeaderNode);
    }

    // VariableDeclarations = { VariableDeclaration | VariableDeclaration }
    private Optional<LinkedList<VariableDeclarationNode>> VariableDeclarations() throws SyntaxErrorException {
        // { VariableDeclaration }
        // ( Identifier Identifier ) First variable must have a type and name
        LinkedList<VariableDeclarationNode> variableDeclarationNodes = new LinkedList<>();
        VariableDeclarationNode variableDeclarationNode;
        // { VariableDeclaration }
        do {
            Optional<VariableDeclarationNode> optionalVariableDeclarationNode2 = VariableDeclaration();
            if(optionalVariableDeclarationNode2.isPresent())
                variableDeclarationNode = optionalVariableDeclarationNode2.get();
            else throw new SyntaxErrorException("Missing Variable Declaration", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
            variableDeclarationNodes.add(variableDeclarationNode);
        } while((!tokens.matchAndRemove(Token.TokenTypes.COMMA).equals(Optional.empty())));
        return Optional.of(variableDeclarationNodes);
    }

    private Optional<VariableDeclarationNode> firstVariableDeclaration() throws SyntaxErrorException {
        // { VariableDeclaration }
        // ( Identifier Identifier ) First variable must have a type and name
        VariableDeclarationNode variableDeclarationNode = new VariableDeclarationNode();
        Optional<Token> identifier = tokens.matchAndRemove(Token.TokenTypes.WORD);
        if(identifier.isPresent()) {
            variableDeclarationNode.type = identifier.get().getValue();
            Optional<Token> identifier2 = tokens.matchAndRemove(Token.TokenTypes.WORD);
            if (identifier2.isEmpty())
                throw new SyntaxErrorException("Variable Name Expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
            else variableDeclarationNode.name = identifier2.get().getValue();
        }
        else throw new SyntaxErrorException("Variable Type Expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        return Optional.of(variableDeclarationNode);
    }

    // VariableDeclaration = ( Data Type Name | Name )
    private Optional<VariableDeclarationNode> VariableDeclaration() throws SyntaxErrorException {
        VariableDeclarationNode variableDeclarationNode = new VariableDeclarationNode();
        // ( Identifier | Name )
        Optional<Token> identifier1 = tokens.matchAndRemove(Token.TokenTypes.WORD);
        if(identifier1.isEmpty())
            throw new SyntaxErrorException("Missing Variable Identifier or Name", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        Optional<Token> identifier2 = tokens.matchAndRemove(Token.TokenTypes.WORD); //Possible name if result1 is Identifier
        // If Identifier then Name
        if(identifier2.isPresent()) {
            variableDeclarationNode.type = identifier1.get().getValue();
            variableDeclarationNode.name = identifier2.get().getValue();
        }
        else variableDeclarationNode.name = identifier1.get().getValue();
        return Optional.of(variableDeclarationNode);
    }

    // NewLines = { NewLine | NewLines }
    private void RequireNewLine() throws SyntaxErrorException {
        if(tokens.matchAndRemove(Token.TokenTypes.NEWLINE).equals(Optional.empty()))
            throw new SyntaxErrorException("New Line Expected",tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        else while(!tokens.matchAndRemove(Token.TokenTypes.NEWLINE).equals(Optional.empty()));
    }

    // Class = "class" Identifier [ "implements" Identifier { "," Identifier } ] NEWLINE INDENT
    // { Constructor NEWLINE | MethodDeclaration NEWLINE | Member NEWLINE } DEDENT
    private Optional<ClassNode> Class() throws SyntaxErrorException {
        ClassNode classNode = new ClassNode();
        //Name
        Optional<Token> name = tokens.matchAndRemove(Token.TokenTypes.WORD);
        if(name.isEmpty())
            throw new SyntaxErrorException("Missing Class Name", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        else classNode.name = name.get().getValue();
        // [ "implements" Identifier { "," Identifier } ]
        if(!tokens.matchAndRemove(Token.TokenTypes.IMPLEMENTS).equals(Optional.empty())) {
            Optional<Token> interface1 = tokens.matchAndRemove(Token.TokenTypes.WORD);
            if (interface1.isEmpty())
                throw new SyntaxErrorException("Doesn't implement an interface", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
            classNode.interfaces.add(interface1.get().getValue());
            while(!tokens.matchAndRemove(Token.TokenTypes.COMMA).equals(Optional.empty())) {
                interface1 = tokens.matchAndRemove(Token.TokenTypes.WORD);
                if(interface1.isEmpty())
                    throw new SyntaxErrorException("Doesn't implement an interface", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
                classNode.interfaces.add(interface1.get().getValue());
            }
        }
        // Newline
        RequireNewLine();
        // INDENT
        if(tokens.matchAndRemove(Token.TokenTypes.INDENT).equals(Optional.empty()))
            throw new SyntaxErrorException("Indent Expected",tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        // { Constructor NEWLINE | MethodDeclaration NEWLINE | Member NEWLINE }
        int numConstructMemMethod = 0;
        while(tokens.peek(0).isPresent() && tokens.matchAndRemove(Token.TokenTypes.DEDENT).equals(Optional.empty())) {
            // Constructor = "construct" "(" VariableDeclarations ")" NEWLINE MethodBody
            // "construct"
            if (!tokens.matchAndRemove(Token.TokenTypes.CONSTRUCT).equals(Optional.empty())) {
                Optional<ConstructorNode> optionalConstructorNode = Constructor();
                optionalConstructorNode.ifPresent(constructorNode -> classNode.constructors.add(constructorNode));
                // NEWLINE
                if(tokens.peek(0).isPresent() && tokens.peek(0).get().getType().equals(Token.TokenTypes.NEWLINE))
                    RequireNewLine();
                numConstructMemMethod++;
            }
            // Member = VariableDeclaration ["accessor:" Statements] ["mutator:" Statements]
            else if(tokens.peek(0).isPresent()
                    && tokens.peek(0).get().getType().equals(Token.TokenTypes.WORD)
                    && (tokens.peek(1).isPresent()
                    && tokens.peek(1).get().getType().equals(Token.TokenTypes.WORD))) {
                Optional<MemberNode> optionalMemberNode = Member();
                optionalMemberNode.ifPresent(memberNode -> classNode.members.add(memberNode));
                if(!(tokens.peek(0).get().getType().equals(Token.TokenTypes.DEDENT)
                        && (tokens.peek(1).equals(Optional.empty())
                        || tokens.peek(1).get().getType().equals(Token.TokenTypes.DEDENT)))) {
                    RequireNewLine();
                }
                numConstructMemMethod++;
            }
            // MethodDeclaration = ["private"] ["shared"] MethodHeader NEWLINE MethodBody
            else if(tokens.peek(0).get().getType().equals(Token.TokenTypes.PRIVATE)
                    || tokens.peek(0).get().getType().equals(Token.TokenTypes.SHARED)
                    || (tokens.peek(0).get().getType().equals(Token.TokenTypes.WORD)
                    && tokens.peek(1).isPresent()
                    && tokens.peek(1).get().getType().equals(Token.TokenTypes.LPAREN))) {
                Optional<MethodDeclarationNode> optionalMethodDeclarationNode = MethodDeclaration();
                optionalMethodDeclarationNode.ifPresent(methodDeclarationNode -> classNode.methods.add(methodDeclarationNode));
//                if(!tokens.done()&&!tokens.peek(0).get().getType().equals(Token.TokenTypes.DEDENT)
//                        || ((tokens.peek(1).isPresent()
//                        && tokens.peek(1).get().getType().equals(Token.TokenTypes.DEDENT))))
//                    RequireNewLine();
                numConstructMemMethod++;
            }
            else if(numConstructMemMethod < 1)
                throw new SyntaxErrorException("Missing Member, MethodDeclaration or Constructor", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        }
        // DEDENT
        if(!tokens.done()&&tokens.matchAndRemove(Token.TokenTypes.DEDENT).equals(Optional.empty()))
            throw new SyntaxErrorException("Dedent Expected",tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        return Optional.of(classNode);
    }

    // Constructor = "construct" "(" VariableDeclarations ")" NEWLINE MethodBody
    private Optional<ConstructorNode> Constructor() throws SyntaxErrorException {
        ConstructorNode constructorNode = new ConstructorNode();
        // LPAREN
        if(tokens.matchAndRemove(Token.TokenTypes.LPAREN).equals(Optional.empty()))
            throw new SyntaxErrorException("Missing Left Parenthesis", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        LinkedList<VariableDeclarationNode> variableDeclarationNodes;
        // VariableDeclarations
        Optional<Token> getToken = tokens.peek(0);
        Optional<LinkedList<VariableDeclarationNode>> listVDNodes;
        if(getToken.isPresent()&&getToken.get().getType().equals(Token.TokenTypes.WORD)) {
            listVDNodes = VariableDeclarations();
            variableDeclarationNodes = listVDNodes.orElseGet(LinkedList::new);
            while(!variableDeclarationNodes.isEmpty())
                constructorNode.parameters.add(variableDeclarationNodes.removeFirst());
        }
        // RPAREN
        if(tokens.matchAndRemove(Token.TokenTypes.RPAREN).equals(Optional.empty()))
            throw new SyntaxErrorException("Missing Right Parenthesis", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        // NEWLINE
        RequireNewLine();
        // MethodBody
        Optional<ConstructorNode> optionalConstructorNode = MethodBody();
        if(optionalConstructorNode.isPresent()) {
            ConstructorNode tempConstructorNode = optionalConstructorNode.get();
            constructorNode.locals = tempConstructorNode.locals;
            constructorNode.statements = tempConstructorNode.statements;
            return Optional.of(constructorNode);
        }
        return Optional.empty();
    }

    // MethodBody = INDENT { VariableDeclaration NEWLINE } {Statement} DEDENT
    private Optional<ConstructorNode> MethodBody() throws SyntaxErrorException {
        // INDENT
        if(tokens.matchAndRemove(Token.TokenTypes.INDENT).equals(Optional.empty()))
            throw new SyntaxErrorException("Newline expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        ConstructorNode tempConstructorNode = new ConstructorNode();
        // { VariableDeclaration NEWLINE }
        if(tokens.peek(1).isPresent()&& tokens.peek(1).get().getType().equals(Token.TokenTypes.WORD)) {            LinkedList<VariableDeclarationNode> variableDeclarationNodes;
            while (tokens.peek(0).isPresent() && tokens.peek(0).get().getType().equals(Token.TokenTypes.WORD)
                    && (tokens.peek(1).isPresent() && !tokens.peek(1).get().getType().equals(Token.TokenTypes.ASSIGN)
                    && tokens.peek(2).isPresent() && !tokens.peek(2).get().getType().equals(Token.TokenTypes.ASSIGN))) {
                Optional<LinkedList<VariableDeclarationNode>> optionalVariableDeclarationNodes = VariableDeclarations();
                if (optionalVariableDeclarationNodes.isPresent()) {
                    variableDeclarationNodes = optionalVariableDeclarationNodes.get();
                    while (!variableDeclarationNodes.isEmpty())
                        tempConstructorNode.locals.add(variableDeclarationNodes.removeFirst());
                }
                //NEWLINE
                RequireNewLine();
            }
        }
        // {Statement}
        else {
            while (tokens.peek(0).isPresent() && tokens.matchAndRemove(Token.TokenTypes.DEDENT).equals(Optional.empty())) {
                Optional<ConstructorNode> tempConstructorNode2 = Statement();
                if (tempConstructorNode2.isPresent())
                    while (!tempConstructorNode2.get().statements.isEmpty())
                        tempConstructorNode.statements.add(tempConstructorNode2.get().statements.removeFirst());
                if (tokens.peek(0).isPresent() && !tokens.peek(0).get().getType().equals(Token.TokenTypes.DEDENT))
                    RequireNewLine();
            }
        }
        return Optional.of(tempConstructorNode);
    }

    //Statements = INDENT {Statement NEWLINE } DEDENT
    private Optional<List<StatementNode>> Statements() throws SyntaxErrorException {
        LinkedList<StatementNode> statementNodes = new LinkedList<>();
        //INDENT
        if(tokens.peek(0).isPresent() && !(tokens.peek(0).get().getType().equals(Token.TokenTypes.DEDENT)
                && (tokens.peek(1).isEmpty()
                || tokens.peek(1).get().getType().equals(Token.TokenTypes.DEDENT)))) {
            if (tokens.matchAndRemove(Token.TokenTypes.INDENT).equals(Optional.empty()))
                throw new SyntaxErrorException("Indent Expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
            // { Statement NEWLINE }
            while (!tokens.done() && !tokens.peek(0).get().getType().equals(Token.TokenTypes.DEDENT)) {
                Optional<ConstructorNode> tempConstructorNode = Statement();
                if(tempConstructorNode.isPresent())
                    while(!tempConstructorNode.get().statements.isEmpty())
                        statementNodes.add(tempConstructorNode.get().statements.removeFirst());
                if(tokens.peek(0).isPresent() && tokens.peek(0).get().getType().equals(Token.TokenTypes.NEWLINE))
                        RequireNewLine();
            }
        }
        if (tokens.matchAndRemove(Token.TokenTypes.DEDENT).equals(Optional.empty()))
            throw new SyntaxErrorException("Dedent Expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        return Optional.of(statementNodes);
    }

    //Statement = If | Loop | MethodCall | Assignment
    private Optional<ConstructorNode> Statement() throws SyntaxErrorException {
        // If = "if" BoolExp NEWLINE Statements ["else" NEWLINE (Statement | Statements)]
        // "if"
        ConstructorNode tempConstructorNode = new ConstructorNode();
        if(!tokens.matchAndRemove(Token.TokenTypes.IF).equals(Optional.empty())) {
            Optional<IfNode> optionalIfStatementNode = IfStatement();
            optionalIfStatementNode.ifPresent(ifNode -> tempConstructorNode.statements.add(ifNode));
        }
        //Loop = [VariableReference "=" ] "loop" ( BoolExpTerm ) NEWLINE Statements
        else if(!tokens.matchAndRemove(Token.TokenTypes.LOOP).equals(Optional.empty())) {
            Optional<LoopNode> optionalLoopNode = LoopStatement();
            optionalLoopNode.ifPresent(loopNode -> tempConstructorNode.statements.add(loopNode));
        }
        Optional<StatementNode> optionalStatementNode = disambiguate();
        if(optionalStatementNode.isPresent())
            tempConstructorNode.statements.add(optionalStatementNode.get());
        else if(!tokens.matchAndRemove(Token.TokenTypes.INDENT).equals(Optional.empty()));
        else if(!tokens.matchAndRemove(Token.TokenTypes.DEDENT).equals(Optional.empty()));
        else throw new SyntaxErrorException("Statement Expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        return Optional.of(tempConstructorNode);
    }

    //Meant to disambiguate between MethodCall, Assignment and loop
    private Optional<StatementNode> disambiguate() throws SyntaxErrorException {
        // Check for empty method call
        Optional<MethodCallExpressionNode> optionalMethodCallExpressionNode = MethodCallExpression();
        if(optionalMethodCallExpressionNode.isPresent()) {
            MethodCallExpressionNode methodCallExpressionNode = optionalMethodCallExpressionNode.get();
            MethodCallStatementNode methodCallStatementNode = new MethodCallStatementNode();
            methodCallStatementNode.methodName = methodCallExpressionNode.methodName;
            methodCallStatementNode.objectName = methodCallExpressionNode.objectName;
            methodCallStatementNode.parameters = methodCallExpressionNode.parameters;
            return Optional.of(methodCallStatementNode);
        }
        Optional<VariableReferenceNode> optionalVariableReferenceNode = VariableReference();
        if(optionalVariableReferenceNode.isPresent()) {
            VariableReferenceNode variableReferenceNode = optionalVariableReferenceNode.get();
            // Comma means it must be MethodCall
            if(tokens.peek(0).isPresent() && tokens.peek(0).get().getType().equals(Token.TokenTypes.COMMA))
                return MethodCall(variableReferenceNode);
            // Loop means there's a loop
            else if(!tokens.matchAndRemove(Token.TokenTypes.LOOP).equals(Optional.empty())) {
                Optional<LoopNode> optionalLoopNode = LoopStatement();
                if(optionalLoopNode.isPresent()) {
                    LoopNode loopNode = optionalLoopNode.get();
                    return Optional.of(loopNode);
                }
            }
            // Assignment = VariableReference "=" Expression
            // MethodCall = [VariableReference { "," VariableReference } "=" MethodCallExpression
            // "="
            else if(!tokens.matchAndRemove(Token.TokenTypes.ASSIGN).equals(Optional.empty())) {
                optionalMethodCallExpressionNode = MethodCallExpression();
                if(optionalMethodCallExpressionNode.isPresent()) {
                    MethodCallExpressionNode methodCallExpressionNode = optionalMethodCallExpressionNode.get();
                    MethodCallStatementNode methodCallStatementNode = new MethodCallStatementNode();
                    methodCallStatementNode.methodName = methodCallExpressionNode.methodName;
                    methodCallStatementNode.objectName = methodCallExpressionNode.objectName;
                    methodCallStatementNode.parameters = methodCallExpressionNode.parameters;
                    methodCallStatementNode.returnValues.add(variableReferenceNode);
                    return Optional.of(methodCallStatementNode);
                }
                AssignmentNode assignmentNode = new AssignmentNode();
                // VariableReference
                assignmentNode.target = variableReferenceNode;

                // Expression
                Optional<ExpressionNode> optionalExpressionNode = Expression();
                optionalExpressionNode.ifPresent(expressionNode -> assignmentNode.expression = expressionNode);

                return Optional.of(assignmentNode);
            }
        }
        return Optional.empty();
    }

    // MethodCall = [ VariableReference { "," VariableReference } "=" MethodCallExpression
    private Optional<StatementNode> MethodCall(VariableReferenceNode variableReferenceNode) throws SyntaxErrorException {
        MethodCallStatementNode methodCallStatementNode = new MethodCallStatementNode();
        // { "," VariableReference }
        while(tokens.matchAndRemove(Token.TokenTypes.COMMA).isPresent()) {
            methodCallStatementNode.returnValues.add(variableReferenceNode);
            Optional<VariableReferenceNode> optionalVariableReferenceNode = VariableReference();
            if(optionalVariableReferenceNode.isEmpty())
                throw new SyntaxErrorException("Missing variable reference after \",\"", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
            variableReferenceNode = optionalVariableReferenceNode.get();
        }
        // Add the final variable reference node after the previous comma
        methodCallStatementNode.returnValues.add(variableReferenceNode);
        // "="
        if(tokens.matchAndRemove(Token.TokenTypes.ASSIGN).equals(Optional.empty()))
            throw new SyntaxErrorException("Missing assignment", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        // MethodCallExpression
        Optional<MethodCallExpressionNode> optionalMethodCallExpressionNode = MethodCallExpression();
        if(optionalMethodCallExpressionNode.isPresent()) {
            MethodCallExpressionNode methodCallExpressionNode = optionalMethodCallExpressionNode.get();
            methodCallStatementNode.methodName = methodCallExpressionNode.methodName;
            methodCallStatementNode.objectName = methodCallExpressionNode.objectName;
            methodCallStatementNode.parameters = methodCallExpressionNode.parameters;
            return Optional.of(methodCallStatementNode);
        }
        return Optional.empty();
    }

    // If = "if" BoolExp NEWLINE Statements ["else" NEWLINE (Statement | Statements)]
    private Optional<IfNode> IfStatement() throws SyntaxErrorException {
        IfNode ifNode = new IfNode();
        // BoolExp
        Optional<ExpressionNode> optionalBooleanOpNode = BoolExpTerm();
        ifNode.condition = optionalBooleanOpNode.orElse(null);
        // NEWLINE
        RequireNewLine();
        // Statements
        Optional<List<StatementNode>> optionalStatementNode = Statements();
        if(optionalStatementNode.isPresent()) {
            List<StatementNode> statementNodes = optionalStatementNode.get();
            ifNode.statements = new LinkedList<>();
            while (!statementNodes.isEmpty())
                ifNode.statements.add(statementNodes.removeFirst());
        }
        // [ "else" NEWLINE ( Statement | Statements )
        // [ "else"
        if(!tokens.matchAndRemove(Token.TokenTypes.ELSE).equals(Optional.empty())){
            ElseNode elseNode = new ElseNode();
            //NEWLINE
            RequireNewLine();
            // ( Statement | Statements )
            Optional<List<StatementNode>> optionalStatementNodes = Statements();
            if(optionalStatementNodes.isPresent()) {
                List<StatementNode> elseStatementNodes = optionalStatementNodes.get();
                while (!elseStatementNodes.isEmpty())
                    elseNode.statements.add(elseStatementNodes.removeFirst());
                ifNode.elseStatement = Optional.of(elseNode);
            }
        }
        else ifNode.elseStatement = Optional.empty();
        return Optional.of(ifNode);
    }

    // BoolExpTerm = BoolExpFactor {("and"|"or") BoolExpTerm } | "not" BoolExpTerm
    private Optional<ExpressionNode> BoolExpTerm() throws SyntaxErrorException {
        // BoolExpFactor
        Optional<ExpressionNode> optionalExpressionNode = getNextFactor();

        ExpressionNode expressionNode;
        if(optionalExpressionNode.isPresent())
            expressionNode = optionalExpressionNode.get();
        else throw new SyntaxErrorException("Missing Boolean Expression Factor", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());

        BooleanOpNode booleanOpNode = new BooleanOpNode();
        booleanOpNode.left = null;
        // If there is an upcoming and || or the left of the BooleanOpNode
        if(tokens.peek(0).isPresent()
            && (tokens.peek(0).get().getType().equals(Token.TokenTypes.AND)
            || tokens.peek(0).get().getType().equals(Token.TokenTypes.OR))) {
            booleanOpNode.left = expressionNode;
            booleanOpNode.right = null;
        }
        // Otherwise we return the expressionNode
        else return Optional.of(expressionNode);

        // {("and"|"or") BoolExpTerm }
        while (tokens.peek(0).isPresent()
                && (tokens.peek(0).get().getType().equals(Token.TokenTypes.AND)
                || tokens.peek(0).get().getType().equals(Token.TokenTypes.OR))) {

            //Determining if the token is an AND token or an OR token
            boolean isAnd = false;
            if (!tokens.matchAndRemove(Token.TokenTypes.AND).equals(Optional.empty()))
                isAnd = true;
            else
                tokens.matchAndRemove(Token.TokenTypes.OR);

            // Get the next BoolExpFactor
            optionalExpressionNode = getNextFactor();

            // If booleanOpNode.right != null it's not the first time through which means the left
            // and right nodes will be filled so we must make a new parent node
            if (booleanOpNode.right != null) {
                BooleanOpNode tempBooleanOpNode = new BooleanOpNode();
                tempBooleanOpNode.left = booleanOpNode;
                booleanOpNode = tempBooleanOpNode;
            }

            // Set the BooleanOpNode's op member based on if the token was an and || or
            if(isAnd)
                booleanOpNode.op = BooleanOpNode.BooleanOperations.and;
            else booleanOpNode.op = BooleanOpNode.BooleanOperations.or;

            // Add the BoolExpFactor to the right of the booleanOpNode if it exists
            if (optionalExpressionNode.isPresent())
                booleanOpNode.right = optionalExpressionNode.get();
            else
                throw new SyntaxErrorException("Missing Boolean Expression Factor", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());

        }
        return Optional.of(booleanOpNode);
    }

    // This gets the next factor but includes BooleanOpNodes as well for the specific case in BoolExpTerm
    private Optional<ExpressionNode> getNextFactor() throws SyntaxErrorException {
        Optional<Token> notToken = tokens.matchAndRemove(Token.TokenTypes.NOTEQUAL);

        // BoolExpFactor
        Optional<ExpressionNode> optionalExpressionNode = BoolExpFactor();
        ExpressionNode expressionNode;
        if (optionalExpressionNode.isPresent())
            expressionNode = optionalExpressionNode.get();
        else
            throw new SyntaxErrorException("Missing Boolean Expression Factor", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());

        // Check if this is a notOpNode
        NotOpNode notOpNode = new NotOpNode();
        notOpNode.left = null;
        if (notToken.isPresent()){
            notOpNode.left = expressionNode;
            expressionNode = notOpNode;
        }

        return Optional.of(expressionNode);
    }

    // BoolExpFactor = MethodCallExpression | (Expression ( "==" | "!=" | "<=" | ">=" | ">" | "<" )
    // Expression) | VariableReference
    private Optional<ExpressionNode> BoolExpFactor() throws SyntaxErrorException {
        if(tokens.peek(0).isPresent() && tokens.peek(0).get().getType().equals(Token.TokenTypes.WORD)){
            // Method Call Expression
            if(tokens.peek(1).isPresent() && (tokens.peek(1).get().getType().equals(Token.TokenTypes.LPAREN)
                    || tokens.peek(1).get().getType().equals(Token.TokenTypes.DOT))) {
                //Check for MethodCallExpression return an Optional.empty() if MethodCallExpression() returns empty
                MethodCallExpressionNode methodCallExpressionNode;
                Optional<MethodCallExpressionNode> optionalMethodCallExpressionNode = MethodCallExpression();
                if(optionalMethodCallExpressionNode.isPresent()) {
                    methodCallExpressionNode = optionalMethodCallExpressionNode.get();
                    return Optional.of(methodCallExpressionNode);
                }
                return Optional.empty();
            }
            else if(tokens.peek(1).isPresent() &&
                    ((tokens.peek(1).get().getType().equals(Token.TokenTypes.EQUAL)) ||
                    tokens.peek(1).get().getType().equals(Token.TokenTypes.NOTEQUAL)) ||
                    tokens.peek(1).get().getType().equals(Token.TokenTypes.LESSTHANEQUAL) ||
                    tokens.peek(1).get().getType().equals(Token.TokenTypes.LESSTHAN) ||
                    tokens.peek(1).get().getType().equals(Token.TokenTypes.GREATERTHAN) ||
                    tokens.peek(1).get().getType().equals(Token.TokenTypes.GREATERTHANEQUAL)){
                Optional<CompareNode> optionalCompareNode = CompareNode();
                if(optionalCompareNode.isPresent())
                    return Optional.of(optionalCompareNode.get());
                return Optional.empty();
            }
            // Variable Reference
            else {
                Optional<VariableReferenceNode> optionalVariableReferenceNode = VariableReference();
                if(optionalVariableReferenceNode.isPresent()) {
                    VariableReferenceNode variableReferenceNode = optionalVariableReferenceNode.get();
                    return Optional.of(variableReferenceNode);
                }
                throw new SyntaxErrorException("Missing Identifier", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
            }
        }
        // Expression ( "==" | "!=" | "<=" | ">=" | ">" | "<" ) Expression
        else if(tokens.peek(0).isPresent() && (tokens.peek(0).get().getType().equals(Token.TokenTypes.NUMBER))) {
            Optional<CompareNode> optionalCompareNode = CompareNode();
            if(optionalCompareNode.isPresent())
                return Optional.of(optionalCompareNode.get());
            return Optional.empty();
        }
        throw new SyntaxErrorException("No Boolean Expression Factor found.", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
    }

    // CompareNode = Expression ( "==" | "!=" | "<=" | ">=" | ">" | "<" ) Expression
    private Optional<CompareNode> CompareNode() throws SyntaxErrorException {
        CompareNode compareNode = new CompareNode();

        // Expression
        // Check if expression returns an Optional.empty()
        Optional<ExpressionNode> optionalExpressionNode = Expression();
        compareNode.left = optionalExpressionNode.orElse(null);

        // ( '==' | )
        if(!tokens.matchAndRemove(Token.TokenTypes.EQUAL).equals(Optional.empty()))
            compareNode.op = CompareNode.CompareOperations.eq;
            // ( "!=" | )
        else if(!tokens.matchAndRemove(Token.TokenTypes.NOTEQUAL).equals(Optional.empty()))
            compareNode.op = CompareNode.CompareOperations.ne;
            // ( "<=" | )
        else if(!tokens.matchAndRemove(Token.TokenTypes.LESSTHANEQUAL).equals(Optional.empty()))
            compareNode.op = CompareNode.CompareOperations.le;
            // ( ">=" | )
        else if(!tokens.matchAndRemove(Token.TokenTypes.GREATERTHANEQUAL).equals(Optional.empty()))
            compareNode.op = CompareNode.CompareOperations.ge;
            // ( ">" | )
        else if(!tokens.matchAndRemove(Token.TokenTypes.GREATERTHAN).equals(Optional.empty()))
            compareNode.op = CompareNode.CompareOperations.gt;
            // ( "<" )
        else if(!tokens.matchAndRemove(Token.TokenTypes.LESSTHAN).equals(Optional.empty()))
            compareNode.op = CompareNode.CompareOperations.le;
        else throw new SyntaxErrorException("Missing boolean operator", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());

        // Expression
        // Check if expression returns an Optional.empty()
        Optional<ExpressionNode> optionalExpressionNode2 = Expression();
        compareNode.right = optionalExpressionNode2.orElse(null);

        return Optional.of(compareNode);
    }

    //Expression = Term { ("+"|"-") Term }
    private Optional<ExpressionNode> Expression() throws SyntaxErrorException {
        //Term
        Optional<ExpressionNode> optionalTerm = Term();

        if(optionalTerm.isEmpty())
            return Optional.empty();

        // { ("+"|"-") Term }
        MathOpNode mathOpNode = new MathOpNode();
        mathOpNode.left = optionalTerm.get();
        mathOpNode.right = null;
        while(tokens.peek(0).isPresent() && (tokens.peek(0).get().getType().equals(Token.TokenTypes.PLUS)
                || tokens.peek(0).get().getType().equals(Token.TokenTypes.MINUS))) {
            // This is a variable that holds if the operator was a plus or not
            boolean isPlus = tokens.matchAndRemove(Token.TokenTypes.PLUS).isPresent();
            if(!isPlus)
                tokens.matchAndRemove(Token.TokenTypes.MINUS);

            // Term
            optionalTerm = Term();

            // Prepare the mathOpNode
            mathOpNode = setMathOpNode(mathOpNode, optionalTerm);

            // Sets the mathOpNode op to the corresponding operator we found earlier
            if(isPlus)
                mathOpNode.op = MathOpNode.MathOperations.add;
            else mathOpNode.op = MathOpNode.MathOperations.subtract;
        }

        if(mathOpNode.right != null)
            return Optional.of(mathOpNode);
        return optionalTerm;
    }

    // Term = Factor { ("*"|"/"|"%") Factor }
    private Optional<ExpressionNode> Term() throws SyntaxErrorException {
        //Factor
        Optional<ExpressionNode> optionalFactor = Factor();
        if(optionalFactor.isEmpty())
            return Optional.empty();

        // { ("*"|"/"|"%") Factor }
        MathOpNode mathOpNode = new MathOpNode();
        mathOpNode.left = optionalFactor.get();
        mathOpNode.right = null;
        while(tokens.peek(0).isPresent() && (tokens.peek(0).get().getType().equals(Token.TokenTypes.TIMES)
                || tokens.peek(0).get().getType().equals(Token.TokenTypes.DIVIDE)
                || tokens.peek(0).get().getType().equals(Token.TokenTypes.MODULO))) {
            // This is a variable that holds which operation is used
            int isTimesDivideOrModulo;

            // "*"
            if(tokens.matchAndRemove(Token.TokenTypes.TIMES).isPresent())
                isTimesDivideOrModulo = 0;
            // "/"
            else if(tokens.matchAndRemove(Token.TokenTypes.DIVIDE).isPresent())
                isTimesDivideOrModulo = 1;
            // "%"
            else if(tokens.matchAndRemove(Token.TokenTypes.MODULO).isPresent())
                isTimesDivideOrModulo = 2;
            // If none throw exception
            else throw new SyntaxErrorException("Missing Operator", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());

            // Factor
            optionalFactor = Factor();

            // Prepare the mathOpNode
            mathOpNode = setMathOpNode(mathOpNode, optionalFactor);

            // Sets the mathOpNode op to the corresponding operator we found earlier
            if(isTimesDivideOrModulo == 0)
                mathOpNode.op = MathOpNode.MathOperations.multiply;
            else if(isTimesDivideOrModulo == 1)
                mathOpNode.op = MathOpNode.MathOperations.divide;
            else mathOpNode.op = MathOpNode.MathOperations.modulo;
        }

        // If the right side is null there was not an operator so return the factor we initially found
        if(mathOpNode.right == null)
            return optionalFactor;
        else return Optional.of(mathOpNode);
    }

    // This sets the mathOpNode and checks if the optionalExpressionNode is empty
    MathOpNode setMathOpNode(MathOpNode mathOpNode, Optional<ExpressionNode> optionalExpressionNode) throws SyntaxErrorException {
        if(optionalExpressionNode.isEmpty())
            throw new SyntaxErrorException("Missing Factor", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());

        // Places the new factor in the right if there isn't one or moves the previous math operations
        // to the left side of a new MathOpNode
        if(mathOpNode.right != null) {
            MathOpNode tempMathOpNode = new MathOpNode();
            tempMathOpNode.left = mathOpNode;
            mathOpNode = tempMathOpNode;
        }
        mathOpNode.right = optionalExpressionNode.get();

        return mathOpNode;
    }

    // Factor = NumberLiteral | VariableReference | "true" | "false" | StringLiteral | CharacterLiteral
    // | MethodCallExpression | "(" Expression ")" | "new" Identifier "(" [Expression {"," Expression }] ")"
    private Optional<ExpressionNode> Factor() throws SyntaxErrorException {
        // NumberLiteral
        Optional<Token> numberToken = tokens.matchAndRemove(Token.TokenTypes.NUMBER);
        if(numberToken.isPresent()){
            NumericLiteralNode numericLiteralNode = new NumericLiteralNode();
            numericLiteralNode.value = Float.parseFloat(numberToken.get().getValue());
            return Optional.of(numericLiteralNode);
        }

        // VariableReference | MethodCallExpression
        if(tokens.peek(0).isPresent() && tokens.peek(0).get().getType().equals(Token.TokenTypes.WORD)) {
            // MethodCallExpression
            if(tokens.peek(1).isPresent() && (tokens.peek(1).get().getType().equals(Token.TokenTypes.LPAREN)
                || tokens.peek(1).get().getType().equals(Token.TokenTypes.DOT))) {

                Optional<MethodCallExpressionNode> optionalMethodCallExpressionNode = MethodCallExpression();
                if(optionalMethodCallExpressionNode.isEmpty())
                    throw new SyntaxErrorException("Missing method call expression", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
                return Optional.of(optionalMethodCallExpressionNode.get());
            }

            // VariableReference
            Optional<VariableReferenceNode> optionalVariableReferenceNode = VariableReference();
            if(optionalVariableReferenceNode.isEmpty())
                throw new SyntaxErrorException("Missing variable reference", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
            return Optional.of(optionalVariableReferenceNode.get());
        }

        // "true"
        if(tokens.matchAndRemove(Token.TokenTypes.TRUE).isPresent()){
            BooleanLiteralNode booleanLiteralNode = new BooleanLiteralNode(true);
            return Optional.of(booleanLiteralNode);
        }

        // "false"
        if(tokens.matchAndRemove(Token.TokenTypes.FALSE).isPresent()){
            BooleanLiteralNode booleanLiteralNode = new BooleanLiteralNode(false);
            return Optional.of(booleanLiteralNode);
        }

        // StringLiteral
        Optional<Token> stringLiteralToken = tokens.matchAndRemove(Token.TokenTypes.QUOTEDSTRING);
        if(stringLiteralToken.isPresent()){
            StringLiteralNode stringLiteralNode = new StringLiteralNode();
            stringLiteralNode.value = stringLiteralToken.get().getValue();
            return Optional.of(stringLiteralNode);
        }

        // CharacterLiteral
        Optional<Token> characterLiteralToken = tokens.matchAndRemove(Token.TokenTypes.QUOTEDCHARACTER);
        if(characterLiteralToken.isPresent()){
            CharLiteralNode charLiteralNode = new CharLiteralNode();
            charLiteralNode.value = characterLiteralToken.get().getValue().charAt(0);
            return Optional.of(charLiteralNode);
        }

        // "(" Expression ")"
        if(tokens.matchAndRemove(Token.TokenTypes.LPAREN).isPresent()){
            Optional<ExpressionNode> optionalExpressionNode = Expression();
            if(optionalExpressionNode.isEmpty())
                throw new SyntaxErrorException("Missing expression", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
            if(tokens.matchAndRemove(Token.TokenTypes.RPAREN).isEmpty())
                throw new SyntaxErrorException("Missing Right Parenthesis", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
            return optionalExpressionNode;
        }

        // "new" Identifier "(" [ Expression { "," Expression } ] ")"
        if(tokens.matchAndRemove(Token.TokenTypes.NEW).isPresent()){
            // Rest can be treated as a methodCallExpression
            Optional<MethodCallExpressionNode> optionalMethodCallExpressionNode = MethodCallExpression();
            if(optionalMethodCallExpressionNode.isEmpty())
                throw new SyntaxErrorException("Missing class call", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());

            MethodCallExpressionNode methodCallExpressionNode = optionalMethodCallExpressionNode.get();
            // Create the new Node
            NewNode newNode = new NewNode();

            // Cannot have Identifier.Identifier for this
            if(methodCallExpressionNode.objectName != null && methodCallExpressionNode.objectName.isPresent())
                throw new SyntaxErrorException("Must be a class, not a method", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());

            // Place the values in the NewNode
            newNode.className = methodCallExpressionNode.methodName;
            newNode.parameters = methodCallExpressionNode.parameters;

            return Optional.of(newNode);
        }

        // If none return Optional empty
        return Optional.empty();
    }

    // VariableReference = Identifier
    private Optional<VariableReferenceNode> VariableReference() {
        VariableReferenceNode variableReferenceNode = new VariableReferenceNode();
        Optional<Token> nextToken = tokens.matchAndRemove(Token.TokenTypes.WORD);
        if(nextToken.isPresent()) {
            variableReferenceNode.name = nextToken.get().getValue();
            return Optional.of(variableReferenceNode);
        }
        else return Optional.empty();
    }

    // MethodCallExpression = [Identifier "."] Identifier "(" [Expression {"," Expression }] ")"
    private Optional<MethodCallExpressionNode> MethodCallExpression() throws SyntaxErrorException {
        MethodCallExpressionNode methodCallExpressionNode = new MethodCallExpressionNode();

        // Identifier
        if(tokens.peek(1).isPresent() && !(tokens.peek(1).get().getType().equals(Token.TokenTypes.DOT)
                || tokens.peek(1).get().getType().equals(Token.TokenTypes.LPAREN)))
            return Optional.empty();
        Optional<Token> firstIdentifierToken = tokens.matchAndRemove(Token.TokenTypes.WORD);
        if(firstIdentifierToken.isEmpty())
            return Optional.empty();

        // ["."]
        Optional<Token> secondIdentifierToken;
        if(tokens.matchAndRemove(Token.TokenTypes.DOT).isPresent()) {
            // [Identifier "."] Identifier
            secondIdentifierToken = tokens.matchAndRemove(Token.TokenTypes.WORD);
            if(secondIdentifierToken.isEmpty())
                throw new SyntaxErrorException("Missing method name after class name for method call", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
            methodCallExpressionNode.objectName = Optional.of(firstIdentifierToken.get().getValue());
            methodCallExpressionNode.methodName = secondIdentifierToken.get().getValue();
        }
        else {
            methodCallExpressionNode.objectName = Optional.empty();
            methodCallExpressionNode.methodName = firstIdentifierToken.get().getValue();
        }

        // "("
        if(tokens.matchAndRemove(Token.TokenTypes.LPAREN).isEmpty())
            return Optional.empty();

        // [ Expression { "," Expression } ]
        Optional<ExpressionNode> optionalExpressionNode = Expression();
        if(optionalExpressionNode.isPresent()) {
            // Create list and add the already seen expression to list
            ArrayList<ExpressionNode> expressionNodes = new ArrayList<>();
            expressionNodes.add(optionalExpressionNode.get());
            // While there is a comma, there must be another expression
            while(tokens.matchAndRemove(Token.TokenTypes.COMMA).isPresent()) {
                optionalExpressionNode = Expression();
                if(optionalExpressionNode.isEmpty())
                    throw new SyntaxErrorException("Missing parameter in method call", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
                expressionNodes.add(optionalExpressionNode.get());
            }
            // Make the list of expression nodes the list of parameters in methodCallExpressionNode
            methodCallExpressionNode.parameters = expressionNodes;
        }

        // ")"
        if(tokens.matchAndRemove(Token.TokenTypes.RPAREN).isEmpty())
            throw new SyntaxErrorException("Right Parenthesis expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());

        return Optional.of(methodCallExpressionNode);
    }

    //Loop = [VariableReference "=" ] "loop" ( BoolExpTerm | Assignment ) NEWLINE Statements
    private Optional<LoopNode> LoopStatement() throws SyntaxErrorException {
        LoopNode loopNode = new LoopNode();
        // ( BoolExpTerm )
        if(tokens.peek(1).isEmpty() || !tokens.peek(1).get().getType().equals(Token.TokenTypes.ASSIGN)) {
            Optional<ExpressionNode> optionalExpressionNode = BoolExpTerm();
            loopNode.expression = optionalExpressionNode.orElse(null);
        }
        // Assignment = VariableReference "=" Expression
        else{
            AssignmentNode assignmentNode = new AssignmentNode();
            // VariableReference
            Optional<VariableReferenceNode> optionalVariableReferenceNode = VariableReference();
            if(optionalVariableReferenceNode.isEmpty())
                throw new SyntaxErrorException("Assignment detected in loop condition, but variable reference does not precede it", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
            assignmentNode.target = optionalVariableReferenceNode.get();

            // "="
            tokens.matchAndRemove(Token.TokenTypes.ASSIGN);

            // Expression
            Optional<ExpressionNode> optionalExpressionNode = Expression();

            // Assign VariableReference and Expression to loopNode condition
            loopNode.assignment = Optional.of(assignmentNode.target);
            if(optionalExpressionNode.isPresent())
                loopNode.expression = optionalExpressionNode.get();
            else throw new SyntaxErrorException("Missing expression in assignment in loop condition", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
        }

        // NEWLINE
        RequireNewLine();
        // Statements
        Optional<List<StatementNode>> optionalStatementNodes = Statements();
        loopNode.statements = optionalStatementNodes.orElse(null);
        return Optional.of(loopNode);
    }

    // MethodDeclaration = ["private"] ["shared"] MethodHeader NEWLINE MethodBody
    private Optional<MethodDeclarationNode> MethodDeclaration() throws SyntaxErrorException {
        MethodDeclarationNode methodDeclarationNode = new MethodDeclarationNode();
        // ["private"]
        if(!tokens.matchAndRemove(Token.TokenTypes.PRIVATE).equals(Optional.empty()))
            methodDeclarationNode.isPrivate = true;
        // ["shared"]
        if(!tokens.matchAndRemove(Token.TokenTypes.SHARED).equals(Optional.empty()))
            methodDeclarationNode.isShared = true;
        // MethodHeader
        Optional<MethodHeaderNode> optionalMethodHeaderNode = MethodHeader();
        if(optionalMethodHeaderNode.isPresent()) {
            MethodHeaderNode methodHeaderNode = optionalMethodHeaderNode.get();
            methodDeclarationNode.name = methodHeaderNode.name;
            while (!methodHeaderNode.parameters.isEmpty())
                methodDeclarationNode.parameters.add(methodHeaderNode.parameters.removeFirst());
            while (!methodHeaderNode.returns.isEmpty())
                methodDeclarationNode.returns.add(methodHeaderNode.returns.removeFirst());
        }
        // NEWLINE
        RequireNewLine();
        // MethodBody
        Optional<ConstructorNode> optionalConstructorNode = MethodBody();
        if(optionalConstructorNode.isPresent()) {
            ConstructorNode tempConstructorNode = optionalConstructorNode.get();
            methodDeclarationNode.locals = tempConstructorNode.locals;
            methodDeclarationNode.statements = tempConstructorNode.statements;
        }
        return Optional.of(methodDeclarationNode);
    }

    //Member = VariableDeclaration ["accessor:" Statements] ["mutator:" Statements]
    private Optional<MemberNode> Member() throws SyntaxErrorException {
        MemberNode memberNode = new MemberNode();
        // VariableDeclaration
        Optional<VariableDeclarationNode> optionalVariableDeclarationNode = firstVariableDeclaration();
        optionalVariableDeclarationNode.ifPresent(variableDeclarationNode -> memberNode.declaration = variableDeclarationNode);
        // ["accessor:" Statements]
        if(tokens.nextTwoTokensMatch(Token.TokenTypes.NEWLINE, Token.TokenTypes.INDENT)) {
            tokens.matchAndRemove(Token.TokenTypes.NEWLINE);
            tokens.matchAndRemove(Token.TokenTypes.INDENT);
            if (!tokens.matchAndRemove(Token.TokenTypes.ACCESSOR).equals(Optional.empty())) {
                if (tokens.matchAndRemove(Token.TokenTypes.COLON).equals(Optional.empty()))
                    throw new SyntaxErrorException(": Expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
                else if(tokens.peek(0).isPresent() && !tokens.peek(0).get().getType().equals(Token.TokenTypes.DEDENT))
                    memberNode.accessor = Statements();
            }
            // ["mutator:" Statements]
            if (!tokens.matchAndRemove(Token.TokenTypes.MUTATOR).equals(Optional.empty())) {
                if (tokens.matchAndRemove(Token.TokenTypes.COLON).equals(Optional.empty()))
                    throw new SyntaxErrorException(": Expected", tokens.getCurrentLine(), tokens.getCurrentColumnNumber());
                else if(tokens.peek(0).isPresent() && !tokens.peek(0).get().getType().equals(Token.TokenTypes.DEDENT))
                    memberNode.mutator = Statements();
            }
        }
        return Optional.of(memberNode);
    }
}

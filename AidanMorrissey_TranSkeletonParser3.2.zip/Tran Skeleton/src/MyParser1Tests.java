import AST.InterfaceNode;
import AST.TranNode;
//import org.junit.Before;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.*;

public class MyParser1Tests {
    // Helper method to create tokens
    private Token createToken(Token.TokenTypes type, int line, int column, String value) {
        return new Token(type, line, column, value);
    }
    @Test
    public void testPeek() {
        Token token1 = createToken(Token.TokenTypes.WORD, 1, 1, "hello");
        Token token2 = createToken(Token.TokenTypes.NUMBER, 1, 2, "123");
        TokenManager tokenManager = new TokenManager(new LinkedList<>(Arrays.asList(token1, token2)));

        // Check peeking the first token
        Optional<Token> peekToken = tokenManager.peek(0);
        assertTrue(peekToken.isPresent(), "First token should be peeked");
        assertEquals(token1, peekToken.get(), "The first peeked token should be the first token");

        // Check peeking the second token
        Optional<Token> secondPeekToken = tokenManager.peek(1);
        assertTrue(secondPeekToken.isPresent(), "Second token should be peeked");
        assertEquals(token2, secondPeekToken.get(), "The second peeked token should be the second token");

        //Check peeking the "third" token
        Optional<Token> thirdPeekToken = tokenManager.peek(2);
        assertFalse(thirdPeekToken.isPresent(), "Third token should be peeked as Optional.empty");
        assertEquals(Optional.empty(), thirdPeekToken, "Third token should be empty");
    }

    @Test
    public void testNextTwoTokensMatch() {
        Token token1 = createToken(Token.TokenTypes.WORD, 1, 1, "hello");
        Token token2 = createToken(Token.TokenTypes.NUMBER, 1, 2, "123");
        TokenManager tokenManager = new TokenManager(new LinkedList<>(Arrays.asList(token1, token2)));

        // Check if the first two tokens match the given types
        assertTrue(tokenManager.nextTwoTokensMatch(Token.TokenTypes.WORD, Token.TokenTypes.NUMBER),
                "First two tokens should match WORD and NUMBER");

        Token token3 = createToken(Token.TokenTypes.WORD, 1, 1, "hello");
        TokenManager tokenManager2 = new TokenManager(new LinkedList<>(Arrays.asList(token3)));

        // Check if the first two tokens match the given types
        assertFalse(tokenManager2.nextTwoTokensMatch(Token.TokenTypes.WORD, Token.TokenTypes.NUMBER),
                "Second token should not be seen");

        Token token4 = createToken(Token.TokenTypes.WORD, 1, 1, "hello");
        Token token5 = createToken(Token.TokenTypes.NEWLINE, 1, 2, "\n");
        TokenManager tokenManager3 = new TokenManager(new LinkedList<>(Arrays.asList(token4, token5)));

        // Check if the first two tokens match the given types
        assertFalse(tokenManager3.nextTwoTokensMatch(Token.TokenTypes.WORD, Token.TokenTypes.NUMBER),
                "First two tokens should not match WORD and NUMBER");
    }

    @Test
    public void testMatchAndRemove() {
        Token token1 = createToken(Token.TokenTypes.WORD, 1, 1, "hello");
        Token token2 = createToken(Token.TokenTypes.NUMBER, 1, 2, "123");
        TokenManager tokenManager = new TokenManager(new LinkedList<>(Arrays.asList(token1, token2)));

        // Check if the first token matches and is removed
        Optional<Token> matchedToken = tokenManager.matchAndRemove(Token.TokenTypes.WORD);
        assertTrue(matchedToken.isPresent(), "Token should match WORD and be removed");
        assertEquals(token1, matchedToken.get(), "The matched token should be the first token");


        // Check if second token can return null for matchAndRemove with a non NUMBER type
        Optional<Token> matchedToken3 = tokenManager.matchAndRemove(Token.TokenTypes.NEWLINE);
        assertFalse(matchedToken3.isPresent(), "Token should not match NEWLINE");
        assertEquals(Optional.empty(), matchedToken3, "Token should not match NEWLINE");

        // Check if the second token is now the first
        Optional<Token> nextToken = tokenManager.matchAndRemove(Token.TokenTypes.NUMBER);
        assertTrue(nextToken.isPresent(), "Token should match NUMBER and be removed");
        assertEquals(token2, nextToken.get(), "The next token should be the second token");

        // Check if token manager is empty
        assertTrue(tokenManager.done(), "Token manager should be empty");
        Optional<Token> matchedToken4 = tokenManager.matchAndRemove(Token.TokenTypes.WORD);
        assertFalse(matchedToken4.isPresent(), "Token should not match WORD and be removed");
        assertEquals(Optional.empty(), matchedToken4, "Token should not match WORD and be removed");
    }

    @Test
    public void testInterface() throws Exception {
        List<Token> tokens = new ArrayList<>();
        tokens.add(new Token(Token.TokenTypes.INTERFACE, 1, 1, "interface"));
        tokens.add(new Token(Token.TokenTypes.WORD, 1, 11, "someName"));
        tokens.add(new Token(Token.TokenTypes.NEWLINE, 1, 19));
        tokens.add(new Token(Token.TokenTypes.INDENT, 2, 1));
        tokens.add(new Token(Token.TokenTypes.WORD, 2, 2, "updateClock"));
        tokens.add(new Token(Token.TokenTypes.LPAREN, 2, 13));
        tokens.add(new Token(Token.TokenTypes.WORD,2,14, "number"));
        tokens.add(new Token(Token.TokenTypes.WORD,2,15, "a"));
        tokens.add(new Token(Token.TokenTypes.COMMA,2,16));
        tokens.add(new Token(Token.TokenTypes.WORD,2,17, "b"));
        tokens.add(new Token(Token.TokenTypes.COMMA,2,18));
        tokens.add(new Token(Token.TokenTypes.WORD,2,19, "character"));
        tokens.add(new Token(Token.TokenTypes.WORD,2,20, "c"));
        tokens.add(new Token(Token.TokenTypes.RPAREN, 2, 21));
        tokens.add(new Token(Token.TokenTypes.NEWLINE, 2, 22));
        tokens.add(new Token(Token.TokenTypes.WORD, 3, 2, "square"));
        tokens.add(new Token(Token.TokenTypes.LPAREN, 3, 8));
        tokens.add(new Token(Token.TokenTypes.RPAREN, 3, 9));
        tokens.add(new Token(Token.TokenTypes.COLON, 3, 11));
        tokens.add(new Token(Token.TokenTypes.WORD, 3, 13, "number"));
        tokens.add(new Token(Token.TokenTypes.WORD, 3, 20, "s"));
        tokens.add(new Token(Token.TokenTypes.NEWLINE, 3, 21));
        tokens.add(new Token(Token.TokenTypes.DEDENT, 4, 23));

        var tran = new TranNode();
        var p = new Parser(tran, tokens);
        p.Tran();
        Assertions.assertEquals(1, tran.Interfaces.size());
        Assertions.assertEquals(2, tran.Interfaces.getFirst().methods.size());

        //Make sure exception thrown when interface has no name
        List<Token> tokens2 = new ArrayList<>();
        tokens2.add(new Token(Token.TokenTypes.INTERFACE, 1, 1, "interface"));

        var tran2 = new TranNode();
        var p2 = new Parser(tran2, tokens2);
        assertThrows(SyntaxErrorException.class, p2::Tran);

        //Exception thrown when no new line
        List<Token> tokens3 = new ArrayList<>();
        tokens3.add(new Token(Token.TokenTypes.INTERFACE, 1, 1, "interface"));
        tokens3.add(new Token(Token.TokenTypes.WORD, 1, 11, "someName"));

        var tran3 = new TranNode();
        var p3 = new Parser(tran3, tokens3);
        assertDoesNotThrow(p3::Tran);

        //Exception thrown when no indent
        List<Token> tokens4 = new ArrayList<>();
        tokens4.add(new Token(Token.TokenTypes.INTERFACE, 1, 1, "interface"));
        tokens4.add(new Token(Token.TokenTypes.WORD, 1, 11, "someName"));
        tokens4.add(new Token(Token.TokenTypes.NEWLINE,1,12));
        tokens4.add(new Token(Token.TokenTypes.NEWLINE,1,13));
        tokens.add(new Token(Token.TokenTypes.NEWLINE,1,14));

        var tran4= new TranNode();
        var p4 = new Parser(tran4, tokens4);
        assertDoesNotThrow(p4::Tran);

        //Interface with no methods
        List<Token> tokens5 = new ArrayList<>();
        tokens5.add(new Token(Token.TokenTypes.INTERFACE, 1, 1, "interface"));
        tokens5.add(new Token(Token.TokenTypes.WORD, 1, 11, "someName"));
        tokens5.add(new Token(Token.TokenTypes.NEWLINE,1,12));
        tokens5.add(new Token(Token.TokenTypes.INDENT,1,13));
        tokens5.add(new Token(Token.TokenTypes.NEWLINE,1,14));
        tokens5.add(new Token(Token.TokenTypes.NEWLINE,1,15));
        tokens5.add(new Token(Token.TokenTypes.NEWLINE,1,16));
        tokens5.add(new Token(Token.TokenTypes.DEDENT,1,17));

        var tran5= new TranNode();
        var p5 = new Parser(tran5, tokens5);
        Assertions.assertThrows(SyntaxErrorException.class,p5::Tran);
    }
}
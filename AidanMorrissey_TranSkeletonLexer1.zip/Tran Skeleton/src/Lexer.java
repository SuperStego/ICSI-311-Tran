import java.util.LinkedList;
import java.util.List;

/**
 * This class will scan through a String input and place them in a LinkedList of tokens
 */
public class Lexer {
    private final TextManager textM; //Variable to hold a textManager for the String input

    /**
     * Constructor which creates a textManager to hold the input String
     * @param input - Text to be scanned through
     */
    public Lexer(String input) {
        textM = new TextManager(input);
    }

    /**
     * This is the method that actually goes through the text and places the resulting
     * Tokens (words,numbers,punctuation) into a LinkedList of tokens
     * @return - List filled with tokens
     * @throws SyntaxErrorException - Can throw an exception through parsePunctuation() call if there is a
     * character unknown to the lexer
     */
    public List<Token> Lex() throws SyntaxErrorException {
        LinkedList<Token> ListOfTokens = new LinkedList<>();
        Token newToken; //Variable to hold the newest token to be added to the List
        while (!textM.isAtEnd()){
            char aChar = textM.getCharacter(); //Selects the next character in the text to be analyzed
            //Decimal points must be checked as a number in case of a number such as .45
            if(Character.isDigit(aChar) || (aChar == '.'&& Character.isDigit(textM.peekCharacter()))){
                newToken = parseNumber(aChar);
            }
            else if (Character.isLetter(aChar)){
                newToken = parseWord(aChar);
            }
            else {
                newToken = parsePunctuation(aChar);
            }
            if(newToken != null) { //Makes sure not to add any empty Tokens
                ListOfTokens.add(newToken);
            }
        }
        return ListOfTokens;
    }

    /**
     * Method which adds letter to a word until a character which isn't a letter is found
     * @param aChar - char that holds the current Character being analyzed
     * @return - A token holding the word
     */
    private Token parseWord(char aChar) {
        StringBuilder newWord = new StringBuilder();
        newWord.append(aChar); //This character was already found to be a letter
        //Makes sure not to select the next character unless
        //it's a letter (would not be reachable in the rest of the code)
        while(!textM.isAtEnd() && Character.isLetter(textM.peekCharacter())){
            aChar = textM.getCharacter();
            newWord.append(aChar);
        }
        return new Token(Token.TokenTypes.WORD, 0,0, newWord.toString());
    }

    /**
     * Method which adds numbers (and decimals) to a String until either a non-number is found
     * or more than one decimal has been placed in the String
     * @param aChar - char that holds the current character to be analyzed
     * @return - A token with the resulting number
     */
    private Token parseNumber(char aChar){
        boolean seenDot = false; //Keeps track of whether a decimal point has been seen already
        StringBuilder newWord = new StringBuilder(); //Using StringBuilder since it wants to concatenate
        //without creating a new String every time
        if(aChar == '.') //Fixes an error where if a decimal point is the first character
            //The program doesn't remember it's seen a decimal before
            seenDot = true;
        newWord.append(aChar); //Already seen to be a number
        while(!textM.isAtEnd() && ((Character.isDigit(textM.peekCharacter()) || (textM.peekCharacter() == '.' && !seenDot)))){
            aChar = textM.getCharacter();
            if(aChar == '.'){ //If there is a decimal point, checks if there has already been one
                seenDot = true;
            }
            newWord.append(aChar);
        }
        return new Token(Token.TokenTypes.NUMBER, 0, 0, newWord.toString());
    }

    /**
     * Checks what kind of punctuation has been passed through and creates a token with the correct type
     * If the punctuation is unusable, throws an error
     * @param aChar - the character to be analyzed
     * @return - A token which holds the punctuation
     * @throws SyntaxErrorException - If character is unusable by the lexer
     */
    private Token parsePunctuation(char aChar) throws SyntaxErrorException {
        Token newToken;
        if(aChar == '.') {
            newToken = new Token(Token.TokenTypes.DOT,0,0);
        }
        else if (aChar == '+') {
            newToken = new Token(Token.TokenTypes.PLUS,0,0);
        }
        else if (aChar ==  '-'){
            newToken = new Token(Token.TokenTypes.MINUS,0,0);
        }
        else if(aChar == '*'){
            newToken = new Token(Token.TokenTypes.TIMES,0,0);
        }
        else if(aChar == '/'){
            newToken = new Token(Token.TokenTypes.DIVIDE,0,0);
        }
        else if(aChar == '%'){
            newToken = new Token(Token.TokenTypes.MODULO,0,0);
        }
        else if(aChar == '('){
            newToken = new Token(Token.TokenTypes.LPAREN,0,0);
        }
        else if(aChar == ')'){
            newToken = new Token(Token.TokenTypes.RPAREN,0,0);
        }
        else if(aChar == ':'){
            newToken = new Token(Token.TokenTypes.COLON,0,0);
        }
        else if(aChar == ','){
            newToken = new Token(Token.TokenTypes.COMMA,0,0);
        }
        else if(aChar == '='){
            if(!textM.isAtEnd()&&textM.peekCharacter() == '=') {
                textM.getCharacter();
                newToken = new Token(Token.TokenTypes.EQUAL,0,0);
            }
            else{
                newToken = new Token(Token.TokenTypes.ASSIGN,0,0);
            }
        }
        else if(aChar == '!'){
            if(!textM.isAtEnd()&&textM.peekCharacter() == '=') {
                textM.getCharacter();
                newToken = new Token(Token.TokenTypes.NOTEQUAL, 0, 0);
            }
            else{
                newToken = new Token(Token.TokenTypes.NOT,0,0);
            }
        }
        else if(aChar == '<'){
            if(!textM.isAtEnd()&&textM.peekCharacter() == '=') {
                textM.getCharacter();
                newToken = new Token(Token.TokenTypes.LESSTHANEQUAL,0,0);
            }
            else{
                newToken = new Token(Token.TokenTypes.LESSTHAN,0,0);
            }
        }
        else if(aChar == '>'){
            if(!textM.isAtEnd()&&textM.peekCharacter() == '=') {
                textM.getCharacter();
                newToken = new Token(Token.TokenTypes.GREATERTHANEQUAL,0,0);
            }
            else{
                newToken = new Token(Token.TokenTypes.GREATERTHAN,0,0);
            }
        }
        else if(aChar == '&' && (!textM.isAtEnd()&&textM.peekCharacter() == '&')){
                textM.getCharacter();
                newToken = new Token(Token.TokenTypes.AND,0,0);
        }
        else if(aChar == '|'&& (!textM.isAtEnd()&&textM.peekCharacter() == '|')){
            textM.getCharacter();
            newToken = new Token(Token.TokenTypes.OR,0,0);
        }
        else if(aChar == ' '&&textM.peekCharacter()==' '&&textM.peekCharacter(1)==' '&&textM.peekCharacter(2)==' '){
            textM.getCharacter(); //These are needed to make sure the same indent won't get checked more than once
            textM.getCharacter();
            textM.getCharacter();
            newToken = new Token(Token.TokenTypes.INDENT,0,0);
        }
        else if(aChar == '\n'){
            newToken = new Token(Token.TokenTypes.NEWLINE,0,0);
        }
        else if(aChar == ' '){
            newToken = null;
        }
        else {
            throw new SyntaxErrorException("Incorrect character",0,0);
        }
        return newToken;
    }
}
